/*Given an array sorted in non-decreasing order, return the array of squares of each number sorted in non-decreasing order*/
import java.util.Scanner;


class Operation3{

    static void printArray(int[] arr){
        for (int i=0;i<arr.length;i++){
            System.out.print(arr[i]+" ");
        }
        System.out.println();
    }
    static void swap(int[] arr,int i,int j){
        arr[i] = arr[i] + arr[j];
        arr[j] = arr[i] - arr[j];
        arr[i] = arr[i] - arr[j];
    }

    static void reverse(int[] arr){
        int L =0;
        int R = arr.length -1;

        while (L<R){
            swap(arr,L,R);
            L++;
            R--;
        }
    }

    static int[] SquArray(int[] arr){
        int n = arr.length;
        int i=0;
        int j=n-1;
        int k=0;
        int[] ans = new int[n];
        while (i<=j){
            if (Math.abs(arr[i])<Math.abs(arr[j])){
                ans[k++] = arr[j]*arr[j];
                j--;
            }
            else {
                ans[k++] = arr[i]*arr[i];
                i++;
            }
        }
        reverse(ans);
        return ans;
    }
}

public class Ques3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array");
        int n = sc.nextInt();

        int[] arr =new int[n];
        System.out.println("Enter the values in array");
        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
        Operation3.printArray(Operation3.SquArray(arr));

    }
}