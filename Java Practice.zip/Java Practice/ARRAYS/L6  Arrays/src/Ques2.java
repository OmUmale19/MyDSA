/* Given an array of size n. Answer 'q' queries where you need to print the sum of values in given range
* from indices [L to R] where both included*/
//  Note- 1-based indexing

import java.util.Scanner;

class Operation2{

    static int prefixSum(int[] arr,int end){  // The end point upto which we need prefixsum
        int prefSum = 0;
        for (int i=1;i<=end;i++){
            prefSum += arr[i];
        }
        return prefSum;
    }

    static int suffixSum(int[] arr,int start){  // The start point from which suffix sum is started till end
        int suffixSum = 0;
        for (int i=start;i<arr.length;i++){
             suffixSum += arr[i];
        }
        return suffixSum;
    }

    //Method1
    int QuerySum(int[] arr,int L,int R){   // Greater time complexity
        int sum =0;
        for (int i=L;i<=R;i++){
            sum  += arr[i];
        }
        return sum;
    }

    //Method2
    static int QuerySum2(int[] arr,int L,int R){   // We use the logic of prefix sum
        int sum = prefixSum(arr,R) - prefixSum(arr,L-1);
        return sum;
    }
}

public class Ques2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        int n = sc.nextInt();

        int[] arr = new int[n+1];
        System.out.println("Enter the data in array:");
        for (int i=1; i<=n ;i++){
            arr[i] = sc.nextInt();
        }

        System.out.println("Enter the query L and R");
        int L= sc.nextInt();
        int R= sc.nextInt();

        Operation2 obj1 = new Operation2();
        System.out.println("The query sum is:"+ obj1.QuerySum(arr,L,R));

        System.out.println("The query sum is"+Operation2.QuerySum2(arr,L,R));

//        System.out.println(Operation2.suffixSum(arr,R));
    }
}
