/* Write a program to print all natural numbers from n to 1 */

import java.util.Scanner;

public class Main {

    static void printN(int n){

        if (n==1){
            System.out.println(n);
            return;
        }

        System.out.println(n);

        printN(n-1);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        printN(n);

    }
}