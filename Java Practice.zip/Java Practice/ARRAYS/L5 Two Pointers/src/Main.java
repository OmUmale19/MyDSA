// Sort an array having only 0's and 1's
import java.util.Scanner;

public class Main {

    static void PrintArray(int[] arr){
        for (int i=0;i<arr.length;i++){
            System.out.print(arr[i]+"\t");
        }
        System.out.println();
    }

    static void Sort1(int[] arr){   //  Here two traversal methods are used
        int n = arr.length;
        int count =0;    // To count no of zeros
        for (int i=0;i<n;i++){
            if (arr[i]==0){
                count++;
            }
        }
        for (int j=0;j<n;j++){
            if (j<count){
                arr[j] =0;
            }
            else {
                arr[j] =1;
            }
        }
        PrintArray(arr);
    }
    static void swap(int[] arr,int i,int j){
        int temp=  arr[i];
        arr[i] = arr[j];
        arr[j] = temp;

    }

    static void Sort2(int[] arr){ // Within single traversal using swap method
        int n = arr.length;
        int i=0;
        int j=n-1;
        while (i<j){
            if(arr[i]>arr[j]){
                swap(arr,i,j);
            }
            i++;
            j--;
        }
        PrintArray(arr);

    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter size of array");
        int n = sc.nextInt();
        int[] arr =  new int[n];

        for (int i=0;i<arr.length;i++){
            arr[i]= sc.nextInt();
        }
        System.out.println("Sorted array");
        Sort1(arr);
        System.out.println("...........................................");
        Sort2(arr);

    }
}