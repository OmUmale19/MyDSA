// Difference between .equals() and ==

import java.util.Scanner;

public class Equals {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Checking address of diff strings
        String s1 = "Hello";
        String s2 = "Dello";
        System.out.println(s1==s2);
        System.out.println("------------------");

        // Checking for same strings
        String x ="Hello" ;
        String y ="Hello";
        String z = new String("Hello");
        // == Compares address of strings Hence x==y is true
        // But x==z is false because of new address of z
        System.out.println(x==y);
        System.out.println(x==z);
        System.out.println("---------------");

        // In case of sc.nextLine()
        // Although strings are same their address is different
        String a = sc.nextLine();
        String b = sc.nextLine();
        System.out.println(a==b);  // - false
        System.out.println("---------------");

        // To check equality of strings we use .equals()
        System.out.println(s1.equals(s2));
        System.out.println(x.equals(y));
        System.out.println(x.equals(z));
        System.out.println(a.equals(b));

    }
}
