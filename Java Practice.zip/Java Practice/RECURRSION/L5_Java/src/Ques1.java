import java.util.Scanner;

public class Ques1 {
    static void printArr(int[] arr,int n){
        if (n==1){
            System.out.println(arr[n-1]);
            return;
        }
        printArr(arr, n-1);
        System.out.println(arr[n-1]);
    }
    static void printArray(int[] arr,int index){      // index== current index
        if(index == arr.length-1){
            System.out.println(arr[index]);
            return;
        }
        System.out.println(arr[index]);
        printArray(arr,index+1);
    }
    public static void main(String[] args) {
        int[] a = {1,2,3,4,5,6};
        printArr(a,a.length);
        System.out.println("-------------------------------");
        printArray(a,0);
    }
}