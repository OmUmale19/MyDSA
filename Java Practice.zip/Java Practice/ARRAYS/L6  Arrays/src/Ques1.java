/* Given an array, return prefix sum without creating new array
*   Ex- [1,2,3]   ans- [1,3,6]  */

import java.util.Arrays;
import java.util.Scanner;

class Operation1{
    static int[] prefixSumArr(int[] arr){
        for(int i=1;i<arr.length;i++){
            arr[i] += arr[i-1];
        }
        return arr;
    }

    static int[] suffSumArr(int[] arr){
        int n = arr.length;
        for(int i=(n-1)-1;i>=0;i--){
            arr[i] += arr[i+1];
        }
        return arr;
    }

    static int suffSum(int[] arr,int index){    // In terms of prefix sum
        int n= arr.length;
        prefixSumArr(arr);
        int sufSum = arr[n-1] - arr[index-1];
        return sufSum;
    }
}
public class Ques1 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array");
        int n = sc.nextInt();

        int[] arr =new int[n];
        System.out.println("Enter the values in array");
        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }

        int[] arr2 = arr.clone();
        int[] arr3 = arr.clone();

        System.out.println(Arrays.toString(Operation1.prefixSumArr(arr)));
        System.out.println(Arrays.toString(Operation1.suffSumArr(arr2)));
        System.out.println("Suffix sum at index 3 is:"+Operation1.suffSum(arr3,3));
    }
}