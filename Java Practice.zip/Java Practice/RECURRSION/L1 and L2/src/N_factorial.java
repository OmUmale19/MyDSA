import java.util.Scanner;

/* Find the n factorial */
public class N_factorial {
    static long factorial(int n){
        if(n==1){
            return 1;  // Base condition
        }
       long ans = n * factorial(n-1);
        return ans;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the value of n");
        int n = sc.nextInt();
        System.out.println(factorial(n));;
    }
}
