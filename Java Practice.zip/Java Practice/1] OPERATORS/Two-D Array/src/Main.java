import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the value of array size i.e. m and n");
        int m = sc.nextInt();
        int n = sc.nextInt();
        int[][] arr = new int[m][n];

        System.out.println(arr.length);
        System.out.println(arr[0].length);
        /*Here we take 2D array as the array of array and arr[o] consist another array
        * of length equal to columns*/

        System.out.println("________________________________");
        for (int i=0;i<arr.length;i++){
            for (int j=0;j<arr[0].length;j++){
                arr[i][j] = sc.nextInt();
            }
        }
        System.out.println("________________________________");
        for (int i=0;i<arr.length;i++){
            for (int j=0;j<arr[0].length;j++){
                System.out.println(arr[i][j]);
            }
        }

    }
}