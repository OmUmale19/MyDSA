package Stack_using_LL;

public class Part1_LL {
    public static class Node{
        int data;
        Node next;

        public Node(int data){
            this.data = data;
        }
    }
    public static class Stack{
        Node head = null;
        int size = 0;

        void push(int x){
            Node temp = new Node(x);
            if(head==null){
                head = temp;
                size++;
                return;
            }
            temp.next = head;
            head = temp;
            size++;
        }

        int peek(){
            if(head == null){
                System.out.println("Stack is Empty!!");
                return -1;
            }
            return head.data;
        }

        int pop(){
            if(head == null){
                System.out.println("Stack is Empty!!");
                return -1;
            }
            int top = head.data;
            head = head.next;
            size--;
            return top;
        }

        void display(){
            recurrsionDisplay(head);
            System.out.println();
        }
        void recurrsionDisplay(Node head){
            Node temp = head;
            if(temp == null){
                return;
            }
            recurrsionDisplay(temp.next);
            System.out.print(temp.data+" ");
        }

        int size(){
            return size;
        }

        boolean isEmpty(){
            if (head==null) return true;
            else return false;
        }

    }
    public static void main(String[] args) {
        Stack st = new Stack();
        System.out.println("Is stack Empty:"+st.isEmpty());
        st.push(5);
        st.display();
        st.push(10);
        st.display();
        st.push(15);
        st.display();
        st.push(20);
        st.display();
        st.push(25);
        st.display();

        System.out.println("------------------------");
        System.out.println("Popped element :"+st.pop());
        st.display();
        System.out.println("Popped element :"+st.pop());
        st.display();
        System.out.println("Peek element: "+st.peek());;
        st.display();
        System.out.println("Size is :"+st.size());
        System.out.println("Is stack Empty:"+st.isEmpty());
    }
}
