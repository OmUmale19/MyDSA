import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];

        for(int i=0;i<n;i++){
            arr[i]= sc.nextInt();
        }
        int red = 0;
        int white = 0;
        int blue = 0;
        for (int i=0;i<n;i++){
            if(arr[i]==0){
                red++;
            }
            else if (arr[i]==1) {
                white++;
            }
            else {
                blue++;
            }
        }
        System.out.println(red+" "+white+" "+blue);
        int j=0;
        while(j<n){
            if(j<red){
                arr[j] = 0;
            }
            else if (j>= red && j<red+white){
                arr[j] =1;
            }

            else if (j>= white && j<n){
                arr[j] =2;
            }
            j++;
        }
        System.out.println(Arrays.toString(arr));

    }
}