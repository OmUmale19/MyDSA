/*Find the second largest element in an array*/
// Method 1

//import java.util.Arrays;
//import java.util.Scanner;
//
//class SLE{                     // SLE - second largest element
//    static int SecLE(int[] arr) {
//        Arrays.sort(arr);         // Class Arrays is used and method sort is used
//        int S_L_E = 0;
//        for (int i = 0; i < arr.length; i++) {
//            for (int j = i + 1; j < arr.length; j++) {
//                if (arr[i] < arr[j]) {
//                    S_L_E = arr[i];
//                }
//            }
//        }
//        return S_L_E;
//    }
//
//}
//
//public class Main {
//    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter the size");
//        int n = sc.nextInt();
//
//        int[] arr = new int[n];
//
//        System.out.println("Elem");
//        for (int i=0;i<arr.length;i++){
//            arr[i] = sc.nextInt();
//        }
//        System.out.println("Sec L E is: "+SLE.SecLE(arr));
//        System.out.println("S L E "+);
//
//    }
//}
// This approach only works when the array is sorted

//--------------------------------------------------------------------------------------------------------------------------------------
// Method 2

import java.util.Scanner;

public class Main {

    static int findMax(int[] arr){
        // Let the max value is -Infinity i.e. Min Value
        int max = Integer.MIN_VALUE;

        for (int i=0;i<arr.length;i++){
            if (arr[i]>max){
                max = arr[i];
            }
        }
        return max;
    }

    static int secMax(int[] arr,int max){
        int min = Integer.MIN_VALUE;
        for (int i=0;i<arr.length;i++){
            if (arr[i]==max){
                arr[i] = min;
            }
        }
        int SecMax = findMax(arr);
        return SecMax;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter size of array");
        int n = sc.nextInt();
        int[] arr =  new int[n];

        for (int i=0;i<arr.length;i++){
            arr[i]= sc.nextInt();
        }
        System.out.println("Max element is: "+findMax(arr));
        int Max = findMax(arr);
        System.out.println("Second Max is: "+secMax(arr,Max));

    }
}


























