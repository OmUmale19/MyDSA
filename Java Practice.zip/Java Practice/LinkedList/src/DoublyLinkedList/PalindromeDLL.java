package DoublyLinkedList;

public class PalindromeDLL {

    static boolean ispalindrome(implementation.DLL dub){
        implementation.node h = dub.head;
        implementation.node t = dub.tail;
        while (h!=t){
            if (h.data != t.data){
                return false;
            }
            h = h.next;
            t = t.prev;
        }
        return true;
    }

    public static void main(String[] args) {
        implementation.DLL dub = new implementation.DLL();
        dub.insertAtEnd(1);
        dub.insertAtEnd(2);
        dub.insertAtEnd(3);
        dub.insertAtEnd(4);
        dub.insertAtEnd(5);
        dub.insertAtEnd(5);
        dub.insertAtEnd(3);
        dub.insertAtEnd(2);
        dub.insertAtEnd(1);
        implementation.display(dub.head);
        System.out.println("_________________");
        System.out.println("Is palindrome -> "+ispalindrome(dub));
    }
}
