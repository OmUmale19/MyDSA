/* Remove all the target occurences in a string*/

import java.util.Scanner;

public class Main {

    static String Removeindex(String s,char target,int idx){ //currentIndex = idx
        if(idx ==s.length()){
            return "";
        }
        String S_ans = Removeindex(s,target,idx+1);
        char currChar = s.charAt(idx);
        if (currChar != target){
            return  currChar + S_ans;
        }
        return S_ans;
    }

    static String Remove(String s,char target){   //without index

        if (s.length() == 0){
            return "";
        }
        String S_ans = Remove(s.substring(1),target);
        char currChar = s.charAt(0);  // Here curr is always at 0th index
        if (currChar != target){
            return  currChar + S_ans;
        }
        return S_ans;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        char target = sc.next().charAt(0);
        //System.out.println(Removeindex(s,target,0));
        System.out.println(Remove(s,target));
    }
}