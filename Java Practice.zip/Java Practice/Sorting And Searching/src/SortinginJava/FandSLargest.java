package SortinginJava;

import java.util.*;
class FandSLargets {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array");
        int n = sc.nextInt();
        System.out.println("Enter the elements of array");
        int[] arr = new int[n];
        for(int i=0; i<n; i++) {
            arr[i] =sc.nextInt();
        }
        if(arr.length<2) {
            System.out.println("Array must contain at least 2 elements");
            return;
        }
        int FL = Integer.MIN_VALUE;
        int SL = Integer.MIN_VALUE;
        for(int i=0; i<n; i++) {
            if(arr[i]>FL) {      // If the current element is greater than the first largest
                SL = FL;            // Update the second largest to the previous first largest
                FL = arr[i];        // Update the first largest to the current element
            }
            else if(arr[i]>SL && arr[i]!=FL) {     // If the current element is less than the first largest but greater than the second largest
                SL = arr[i];  // Update the second largest to the current element
            }
        }
        System.out.println("Largest element in an array is "+FL);
        if(SL == Integer.MIN_VALUE) {   // Check if a second largest element exists
            System.out.println("There is no second largest element in an array");
        }
        else {
            System.out.println("Second largest element in an array is "+SL);
        }
    }
}
