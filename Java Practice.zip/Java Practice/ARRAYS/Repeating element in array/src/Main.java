/*Return the first value in an array that is repeating if not return -1*/

import java.util.Scanner;

class Repetition{
     static int FirstRepeat(int[] arr){
        int ans = -1;                 // Let's assume initially there is no first repeating
        for (int i=0;i<arr.length;i++){       // Pick the element
            for (int j=i+1;j<arr.length;j++){     // Compare all elem after the picked elements
                if (arr[i] == arr[j]){               // If there exist
                    ans = arr[i];                      // update the ans
                    return ans;                        // return it immediately{YAHA PURA METHOD HI RUK JATA HAI AGE KA}
                    // IF used "break;"  -- ONLY THAT ITERATION IS break other is continued{ i.e. here ans will be 4}
                    // In case of array - {1,5,3,4,6,3,4}
                }
            }
        }
        return ans;
    }
}
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        int n = sc.nextInt();
        int[] arr =  new int[n];

        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }

        int a = Repetition.FirstRepeat(arr);
        System.out.println("The first repeated is: "+a);
    }
}