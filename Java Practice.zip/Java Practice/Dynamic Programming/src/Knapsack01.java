import java.util.Arrays;
import java.util.Scanner;

public class Knapsack01 {

    static void fillarr(int[] arr){
        Scanner scc = new Scanner(System.in);
        for (int i=0;i<arr.length;i++){
            arr[i] = scc.nextInt();
        }
    }

    static int knap(int idx,int W,int[] wt,int[] val){       // W - weight
        if (idx == 0){
            if (wt[0]<=W){
                return val[0];
            }
            else {
                return 0;
            }
        }
        int Take = Integer.MIN_VALUE;
        if (wt[idx] <= W){
            Take = val[idx] + knap(idx-1,W-wt[idx],wt,val);
        }
        int notTake = 0 + knap(idx-1,W,wt,val);
        return Math.max(Take,notTake);
    }

    static int knap1(int idx,int W,int[] wt,int[] val,int[][] dp){    // Using DP   // TC - O(n*m)
        if (idx ==0){
            if (wt[0]<=W){
                return val[0];
            }
            else {
                return 0;
            }
        }
        if (dp[idx][W] != -1){
            return dp[idx][W];
        }
        int take = Integer.MIN_VALUE;
        if (wt[idx]  <= W){
            take = val[idx] + knap1(idx-1,W-wt[idx],wt,val,dp);
        }
        int nottake = 0 + knap1(idx-1,W,wt,val,dp);

        dp[idx][W] = Math.max(take,nottake);
        return dp[idx][W];
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter num of elem");
        int n = sc.nextInt();
        int[] wt = new int[n];
        int[] val = new int[n];
        System.out.println("Enter wt");
        fillarr(wt);
        System.out.println("Enter val");
        fillarr(val);
        System.out.println("Enter Max Capacity");
        int W = sc.nextInt();   // W - Max weight

        int[][] dp = new int[n][W+1];

        for (int[] row : dp){
            Arrays.fill(row,-1);
        }

//        System.out.println(knap(n-1,W,wt,val));
        System.out.println(knap1(n-1,W,wt,val,dp));
    }
}
