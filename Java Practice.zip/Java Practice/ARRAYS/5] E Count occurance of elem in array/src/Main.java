/* Find the count of target element in an array i.e. how many times it gets repeated */

import java.util.Scanner;

class ArrayOcc{             // occurance of element
    static int Count(int[] arr, int target){
        int count =0;
        for (int i=0;i<arr.length;i++){
            if (arr[i]==target){
                count++;
            }
        }
        return count;
    }
}
public class Main {
    public static void main(String[] args) {
        System.out.println("Enter the size of array:");
        Scanner sc =new Scanner(System.in);
        int x= sc.nextInt();
        int[] arr= new int[x];

        System.out.println("Enter the elements of array:");
        for (int i=0;i< arr.length;i++){
            arr[i] = sc.nextInt();
        }

        System.out.println("Enter the target element");
        int target = sc.nextInt();

        System.out.println("The count is: "+ ArrayOcc.Count(arr,target));


    }
}