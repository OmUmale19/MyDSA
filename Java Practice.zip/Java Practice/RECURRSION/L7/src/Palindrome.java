import java.util.Scanner;

public class Palindrome {
    public static String Reverse(String s){   // Without index   TC- O(n2)  // Using reverse method
        if (s.length()== 0){
            return "";
        }
        String S_ans = Reverse(s.substring(1));
        char curr = s.charAt(0);
        return S_ans + curr;
    }

    static void Rev(String s){
        int i =0;
        int j = s.length()-1;
        while (i<j){
            if (s.charAt(i)!= s.charAt(j)){
                System.out.println(s+" is not a palindrome");
                return;
            }
            i++;
            j--;
        }
        System.out.println(s+" is a palindrome");
    }

    static boolean Remov(String s,int l,int r){

        if(l>=r) {  // Base case
            return true;
        }
        return (s.charAt(l)==s.charAt(r) && Remov(s,l+1,r-1));
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String lowerCase_string = s.toLowerCase();  // to convert into small letters
        String rev = Reverse(lowerCase_string);
        if (rev.equals(lowerCase_string)){
            System.out.println(s+" is a palindrome");
        }
        else {
            System.out.println(s+" is not a palindrome");
        }
        System.out.println("------------------------");
        Rev(lowerCase_string);
        System.out.println("------------------------");
        boolean ans = Remov(lowerCase_string,0,s.length()-1);
        if (ans==true){
            System.out.println(s+" is a palindrome");
        }
        else {
            System.out.println(s+" is not a palindrome");
        }
    }
}
