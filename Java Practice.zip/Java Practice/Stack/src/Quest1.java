import java.util.*;

public class Quest1 {

    // Display using recursion
    static void display(Stack<Integer> st){
        if(st.size()==0) return;
        int top = st.pop();
        display(st);
        System.out.print(top+" ");
    }
    // Reverse stack using recursion
    static void reverse(Stack<Integer> st){
        if(st.size()==0) return;
        int top = st.pop();
        System.out.print(top+" ");
        display(st);
    }
    // Display and reverse using arrafy
    static void arr_Stack(Stack<Integer> st){
        int[] arr = new int[st.size()];
        int j = st.size()-1;
        while (st.size()>0){
            arr[j--] = st.pop();
        }

        // Print stack in order
        System.out.println("Stack in order");
        for(int i=0;i<arr.length;i++){
            System.out.print(arr[i]+" ");
        }
        System.out.println();
        System.out.println("________________________");

        System.out.println("Stack in reverse order");
        // Print stack in reverse order
        for(int i=arr.length-1;i>=0;i--){
            System.out.print(arr[i]+" ");
        }
        System.out.println();
    }

    // Print stack using stack
    static void printStack(Stack<Integer> st){
        Stack<Integer> ex = new Stack<>();
        while(st.size()>0){
            ex.push(st.pop());
        }
        while(ex.size()>0){
            System.out.print(ex.peek()+" ");
            st.push(ex.pop());
        }
        System.out.println();
    }

    // Insert at index
    static void insertAtIndex(Stack<Integer> st,int i){   //i -> index
        Scanner sc = new Scanner(System.in);
        Stack<Integer> ex = new Stack<>();
        while (st.size()>i){
            ex.push(st.pop());
        }
        st.push(sc.nextInt());
        while (ex.size()>0){
            st.push(ex.pop());
        }
    }

    public static void main(String[] args) {
        Stack<Integer> st = new Stack<>();
        st.push(5); // Insert into stack
        st.push(6);
        st.push(1);
        st.push(3);
        st.push(8);
        st.push(7);
        insertAtIndex(st,2);
        System.out.println(st);

        printStack(st);
        System.out.println("_______________________________");
        arr_Stack(st);

        System.out.println("_______________________________");
        st.push(5); // Insert into stack
        st.push(6);
        st.push(1);
        st.push(3);
        st.push(8);
        st.push(7);
        display(st);


    }
}
