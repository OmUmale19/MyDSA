package SortinginJava.Tester;

import java.util.Scanner;
// Logic of binary search

public class SquareRoot {
    static int SQRoot(int target){
        int ans = 0;
        int s =0,e=target;
        while (s<=e){
            int mid = s+(e-s)/2;
            int x = mid*mid;
            if (x == target){
                return mid;
            }
            else if (x>target) {
                e = mid-1;
            }
            else {
                s = mid+1;
                ans = mid;
            }
        }
        return ans;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int target = sc.nextInt();
        System.out.println(SQRoot(target));
    }
}
