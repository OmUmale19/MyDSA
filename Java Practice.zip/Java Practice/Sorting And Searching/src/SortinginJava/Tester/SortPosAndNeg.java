package SortinginJava.Tester;
// Sort negatives and positives
// all neg at beg and all pos at end

import java.util.Arrays;
import java.util.Scanner;

public class SortPosAndNeg {

    static void sort(int[] arr){
    int n = arr.length;
    int k=0;

    for (int i=0;i<n;i++){
        if (arr[i]<0){
            int tmp = arr[k];
            arr[k] = arr[i];
            arr[i] = tmp;
            k++;
        }
    }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        int n = sc.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter the elements in array:");
        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
        sort(arr);
        System.out.println(Arrays.toString(arr));
    }
}
