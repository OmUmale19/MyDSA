import java.util.Scanner;

public class Main {

    static int rectSum(int[][] mat,int l1,int r1,int l2,int r2){    // Sol no. 1
        int sum =0;
        for (int i=l1;i<=l2;i++){
            for (int j=r1;j<=r2;j++){
                sum += mat[i][j];
            }
        }
        return sum;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the rows and columns of matrix");
        int m = sc.nextInt();
        int n = sc.nextInt();

        int[][] mat = new int[m][n];

        System.out.println("Enter the data in matrix");
        for (int i=0;i<m;i++){
            for (int j=0;j<n;j++){
                mat[i][j] = sc.nextInt();
            }
        }
        System.out.println("Enter the 1st coordinates");
        int l1 = sc.nextInt();
        int r1 = sc.nextInt();

        System.out.println("Enter the 2nd coordinates");
        int l2 = sc.nextInt();
        int r2 = sc.nextInt();

        System.out.println("The sum is: "+rectSum(mat,l1,r1,l2,r2));

    }
}