/* Rotate the matrix by 90 deg*/


import java.util.Scanner;

public class Ques2 {

    static void printMatrix(int[][] mat){
        for (int i=0;i< mat.length;i++){
            for (int j =0;j<mat[0].length;j++){
                System.out.print(mat[i][j]+"\t");
            }
            System.out.println();
        }
    }

    void matrixRotate(int[][] mat){
        int r1 = mat.length;
        int c1 = mat[0].length;
        int r2 = c1;
        int c2 = r1;
        int[][] ans = new int[r2][c2];   // Based on algorithm
        for (int i=0;i<r2;i++){
            for (int j=0;j<c2;j++){
                ans[i][j] = mat[(c2-1)-j][i];
            }
        }
        printMatrix(ans);
    }

    // OR Method -  Do transpose and then reverse row

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the rows and columns of matrix");
        int r1 = sc.nextInt();
        int c1 = sc.nextInt();

        int[][] mat = new int[r1][c1];

        System.out.println("Enter the data in matrix");
        for (int i=0;i<r1;i++){
            for (int j=0;j<c1;j++){
                mat[i][j] = sc.nextInt();
            }
        }

        Ques2 obj = new Ques2();
        obj.matrixRotate(mat);
    }
}


