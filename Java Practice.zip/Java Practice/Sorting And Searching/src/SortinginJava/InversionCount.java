package SortinginJava;
import java.util.Arrays;
import java.util.Scanner;

public class InversionCount {
    static int cnt =0;
    public static void invCnt(int[] arr, int s, int e) {
        if (s>=e){
            return;
        }
        int mid = s +(e-s)/2;
        invCnt(arr,s,mid);
        invCnt(arr,mid+1,e);
        mergeCount(arr,s,e,mid);
    }

    private static void mergeCount(int[] arr, int s, int e, int mid) {
        int n1 = mid -s+1;
        int n2 = e - mid;
        int[] left = new int[n1];
        int[] right = new int[n2];
        for (int i=0;i<n1;i++){
            left[i] = arr[s+i];
        }
        for (int j=0;j<n2;j++){
            right[j] = arr[mid+1+j];
        }
        int i=0,j=0,k=s;
        while (i<n1 && j<n2){
            if (left[i]<right[j]){
                arr[k++] = left[i++];
            }
            else {
                arr[k++] = right[j++];
                cnt += n1 - i;
            }
        }
        while (i<n1){
            arr[k++] = left[i++];
        }
        while (j<n2){
            arr[k++] = right[j++];
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number of elements in the array:");
        int n = scanner.nextInt();
        int[] arr = new int[n];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }
        invCnt(arr,0,n-1);
        System.out.println(cnt);
    }
}