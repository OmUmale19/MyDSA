// Rotate the array by k times,where k is non-neg and can be greater the n.
import java.util.Scanner;

class Rotation{

    static void PrintArray(int[] arr){
        for (int i=0;i<arr.length;i++){
            System.out.print(arr[i]+"\t");
        }
        System.out.println();
    }

    static void RotUsingSpace(int[] arr,int k){    //Here a new space/array is created
        int n = arr.length;                        // k is how many times rotate
        int[] arr2 =  new int[n];
        int j=0;
        for (int i=n-k;i<n;i++){
            arr2[j++] = arr[i];       // instead using j++ after apan direct arr madhe takla
        }
        for (int i=0;i<n-k;i++){
            arr2[j++] = arr[i];
        }
        PrintArray(arr2);
    }
    static void Swap(int[] arr,int i,int j){    // Two swap two elements
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    static int[] Reverse(int[] arr, int start, int end){   // To reverse the array form start index to  end index
        int i = start;
        int j= end;
        int n=arr.length;
        for (int k=0;k<n;k++){
            if (i<=j){
                Swap(arr,i,j);
                i++;
                j--;
            }
        }
        return arr;
    }

    static void RotInPlace(int[] arr,int k){  // Rotation without using any space
        int n=arr.length;
        Reverse(arr,0,n-k-1);
        Reverse(arr,n-k,n-1);
        Reverse(arr,0,n-1);
        PrintArray(arr);
    }

}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter size of array");
        int n = sc.nextInt();
        int[] arr =  new int[n];

        for (int i=0;i<arr.length;i++){
            arr[i]= sc.nextInt();
        }
        System.out.println("Enter the value of k:");
        int k= sc.nextInt();

        Rotation.RotUsingSpace(arr,k);
        Rotation.RotInPlace(arr,k);

    }
}