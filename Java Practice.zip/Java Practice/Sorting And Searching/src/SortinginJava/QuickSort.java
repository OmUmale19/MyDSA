package SortinginJava;

import java.util.Arrays;
import java.util.Scanner;

public class QuickSort {

    static void QS(int[] arr,int s,int e){
        if(s<e){
            int p = part(arr,s,e);
            QS(arr,s,p-1);
            QS(arr,p+1,e);
        }
    }

    static int part(int[] arr,int s,int e){
        int pivot =arr[e];
        int p = s;   // P is partition index

        for (int i=s;i<e;i++){
            if (arr[i]<pivot){
                int temp = arr[i];
                arr[i] = arr[p];
                arr[p] = temp;
                p++;
            }
        }
        int temp =arr[p];
        arr[p] = arr[e];
        arr[e] = temp;

        return p;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array");
        int n = sc.nextInt();

        System.out.println("Enter the elements of array");
        int[] arr = new int[n];
        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("Sorted array");
        QS(arr,0,n-1);
        System.out.println(Arrays.toString(arr));
    }
}
