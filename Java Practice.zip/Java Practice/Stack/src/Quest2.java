import java.util.*;

public class Quest2 {

    static void popAtIndex(Stack<Integer> st,int i){  // i -> index
        Stack<Integer> ex = new Stack<>();
        while(st.size()>i+1){
            ex.push(st.pop());
        }
        st.pop();
        while (ex.size()>0){
            st.push(ex.pop());
        }
    }

    // Push at bottom
    static void pushbottom(Stack<Integer> st,int ele){   //i -> index
        Stack<Integer> ex = new Stack<>();
        while (st.size()>0){
            ex.push(st.pop());
        }
        st.push(ele);
        while (ex.size()>0){
            st.push(ex.pop());
        }
    }

    // Recursion using push at bottom
    static void reverseNew(Stack<Integer> st){
        if(st.size()==0) return;
        int top = st.pop();
        reverseNew(st);
        pushbottom(st,top);
    }
    public static void main(String[] args) {
        Stack<Integer> st = new Stack<>();
        st.push(5); // Insert into stack
        st.push(6);
        st.push(1);
        st.push(3);
        st.push(8);
        st.push(7);
        popAtIndex(st,2);
        System.out.println(st);

        System.out.println("____________________");
        reverseNew(st);
        System.out.println(st);

    }
}
