// How to create a class and object
// 1]  Access Modifier then
// 2] "class" keyword then
// 3] Name of class(Generally with capital letter)
// then {..............}

// How  to create an object of class
// Syntax- className objectName = new className()
// To access the attributes or methods of object we use syntax-
// objectName.attributes  or  objectName.method()



public class Main {                         //public- Access Mod & Main-Name of class

    static class Student{
        int rollNo1= 24;       // Attributes of class student i.e each obj in this class have rollNo and Name
        int rollNo2= 25;
        String Name1="Prashant";
        String Name2="Rahul";

        int rollNo;
        String Name;
    }
    public static void main(String[] args) {
        Student Stud1= new Student();    //Object Stud1 is created
        Student Stud2=new Student();     //Object Stud1 is created
        Student Stud3=new Student();

        System.out.println(Stud1.Name1);   // used to access attribute i.e. name
        System.out.println(Stud1.rollNo1);

        System.out.println(Stud1.Name2);
        System.out.println(Stud1.rollNo2);

        System.out.println(Stud1.Name);    //Print null as no input
        System.out.println(Stud1.rollNo);  //print 0 as no value available


    }
}