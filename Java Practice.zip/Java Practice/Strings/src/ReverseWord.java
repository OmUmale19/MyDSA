// Reverse each word of string
// ex- I am an engineer
// ans - I ma na reenigne

import java.util.Scanner;

public class ReverseWord {

    static String revWord(String s){   // Dry run-
        String ans ="";
        StringBuilder sb =  new StringBuilder("");
        for (int i=0;i<s.length();i++){
            char ch = s.charAt(i);
            if (ch != ' '){
                sb.append(s.charAt(i));
            }
            else {
                sb.reverse();
                ans += sb;
                ans +=' ';
                sb = new StringBuilder("");
            }
        }
        sb.reverse();
        ans += sb;
        return ans;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string");
        String s = sc.nextLine();
        System.out.println(revWord(s));

    }
}
