package SortinginJava;

import java.util.Arrays;
import java.util.Scanner;

public class CountSort {
    static int Max(int[] arr){
        int max =arr[0];
        for (int i=0;i<arr.length;i++){
            if (arr[i]>max){
                max = arr[i];
            }
        }
        return max;
    }

    static void countsort(int[] arr){    // Unstable algorithm
        int m = Max(arr);
        int[] count =  new int[m+1];

        for (int i=0;i<arr.length;i++){  // Return count in array
            count[arr[i]]++;
        }
        int k=0;
        for (int i=0;i<count.length;i++){
            for (int j=0;j<count[i];j++){
                arr[k++] = i;
            }
        }

    }

    static void prefixSum(int[] arr){
        for (int i=1;i<arr.length;i++){
            arr[i] += arr[i - 1];
        }
    }

    static int[] cs(int[] arr){   // Stable algorithm
        int m = Max(arr);
        int[] count = new int[m+1];
        for (int i=0;i<arr.length;i++){
            count[arr[i]]++;
        }
        prefixSum(count);
        int[] output = new int[arr.length];


        for (int i= arr.length-1;i>=0;i--){
            int idx =count[arr[i]]-1;
            output[idx] = arr[i];
            count[arr[i]]--;
        }
        return output;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        int n = sc.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter the elements in array:");
        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println(Max(arr));
        countsort(arr);
        System.out.println(Arrays.toString(arr));

        System.out.println("---------------------------------");
        System.out.println(Arrays.toString(cs(arr)));

    }
}
