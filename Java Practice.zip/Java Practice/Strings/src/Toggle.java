// Toggle the string -
// ex- PhySiCs -> pHYsIcS

import java.util.Scanner;

public class Toggle {

    static void toggle(StringBuilder s){
        for (int i=0;i<s.length();i++){
            // flag that checks if it is lowercase
            boolean flag = true;   // True if Uppercase
            char ch = s.charAt(i);

            if (ch==' '){   // if there is a space it will leave
                continue;
            }
            int ascii = (int)ch;  //Typecast

            // Numbers also avoided-  0 - 48 and 9 - 57
            if (ascii>=48 && ascii<=57){
                continue;
            }
            if (ascii >=97){
                flag = false;
            }

            if (flag == true){
                ascii += 32;
                s.setCharAt(i,(char)ascii);
            }
            else {
                ascii -= 32;
                s.setCharAt(i,(char)ascii);
            }
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string");
        StringBuilder s = new StringBuilder(sc.nextLine());
        toggle(s);
        System.out.println(s);
    }
}
