import java.util.Scanner;

public class ReverseString {

    static void ReverseString(StringBuilder s){
        int i=0,j=s.length()-1;
        while (i<j){
            char temp = s.charAt(i);
            s.setCharAt(i,s.charAt(j));
            s.setCharAt(j,temp);
            i++;
            j--;
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StringBuilder s = new StringBuilder(sc.nextLine());
        System.out.println("Enter string");
        ReverseString(s);  // hello
        System.out.println(s);  // olleh
        System.out.println("----------------");
        System.out.println(s.reverse());  // "hello" reverse of olleh
    }
}
