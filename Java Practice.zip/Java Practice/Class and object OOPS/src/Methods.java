import java.util.Scanner;

class Algebra{                    // Class algebra is defined
    float sum(float a,float b){       // Method defined without access specifier,therefore we can access-
                                  // -this only by creating object of class
        float ans= a+b;
        return ans;
    }
    static float subtraction(float a,float b){  //Method defined without access specifier,therefore we can access-
                                             //-this by creating object of class
        float ans = a-b;
        return ans;
    }

    static float Multiplication(float a,float b){   //Same as 2nd
        float ans = a*b;
        return ans;
    }

    float Division(int a,int b){     //Same as 1st
        int ans= a/b;
        return ans;
    }
}

public class Methods {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter x and y:");
        float x = sc.nextFloat();
        float y = sc.nextFloat();

        Algebra obj1 = new Algebra();    //We created obj of that algebra class whose method we are calling
        float ans_sum=obj1.sum(x,y);     // hear we created an object and call sum method as an attribute of obj1
                                         // i.e. obj1.sum();
        System.out.println("Sum:"+ans_sum);

        float ans_sub= Algebra.subtraction(x,y);  //Here no need of creating object as we used "static" before
                                                  //-subtraction,hence we take sub as an attribute of Algebra.
        System.out.println("Subtraction:"+ans_sub);

        float ans_mul = Algebra.Multiplication(x,y);   // Same as subtraction
        System.out.println("Multiplication:"+ans_mul);

        Algebra obj2 = new Algebra();     //here we created an obj of class Algebra whose method we are calling

        float ans_div1 = obj2.Division((int)x,(int)y);   /* As "static" is not used we created an object and call
                                                        -division method as attribute of obj2 i.e. obj2.division()
                                                         Here we also used typecasting to change return type of x
                                                         and y as x,y are float but div function take int values */
/*also*/  int ans_div2 = (int)obj2.Division((int)x,(int)y); /*Here we find answer in int form*/
        System.out.println("Division:"+ans_div1);
        System.out.println("Division:"+ans_div2);

        /* Implement Standard Libraries */
        /* Math is a class having inbuilt functions/methods like sqrt(),floor(),ceil(),pow()*/
        System.out.println("Square root of x:"+ Math.sqrt(x));   // Math.sqrt() ~  class.method()
        System.out.println("Square root of y:"+ Math.sqrt(y));

        System.out.println("Value of x^y:"+ Math.pow(x,y));

        System.out.println("Floor or GIF of x:"+Math.floor(x));  // GIF-Greatest integer function
        System.out.println("Floor or GIF of y:"+Math.floor(y));

        System.out.println("Ceil of x:"+Math.ceil(x));
        System.out.println("Ceil of y:"+Math.ceil(y));

    }
}
/* If we want to run a program continuously we can use while loop as
   " while(1!=0){.......} "*/