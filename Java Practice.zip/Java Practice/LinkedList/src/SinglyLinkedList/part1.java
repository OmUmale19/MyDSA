package SinglyLinkedList;

public class part1 {

    public static class node{
        int data;
        node next;
        public node(int data){
            this.data = data;
        }
    }
    public static void main(String[] args) {
        node a = new node(5);
        node b = new node(4);
        node c = new node(3);
        node d = new node(2);
        node e = new node(1);
        // 5 4 3 2 1
        System.out.println(a);  // a is of type node and 'a' has memory address
        // Hence next is also variable for address so its type is node

        a.next = b;    // storing the address of b in a next
        System.out.println(b);
        System.out.println(a.next);
        /* Both these things -> same */

        System.out.println(a.data);
        System.out.println(a.next.data);
        b.next = c;
        c.next = d;
        d.next = e;
        System.out.println(b.next.data);

    }
}
