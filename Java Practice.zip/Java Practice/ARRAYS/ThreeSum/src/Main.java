import java.util.Scanner;
import java.util.SortedMap;

  class Tsum{
      public static void ThreeSum(int arr[]){
          for (int i=0;i<arr.length;i++){
              for (int j=i+1;j<arr.length;j++){
                  for (int k=j+1;k<arr.length;k++){
                      if (arr[i]+arr[j]+arr[k]==0){

                      }
                  }
              }
          }
      }
   }
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the elements of array");
        int n = sc.nextInt();
        int[] arr = new int[n];
        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
    }
}