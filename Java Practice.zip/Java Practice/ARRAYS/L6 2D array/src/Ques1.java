/*  Matrix Addition */

import java.util.Arrays;
import java.util.Scanner;

public class Ques1 {

    static void Sum(int[][] arr1,int[][] arr2){

        int R1 = arr1.length;          int C1 = arr1[0].length;
        int R2 = arr2.length;          int C2 = arr2[0].length;
        if (R1 != R2 || C1!=C2){
            System.out.println("Multiplication not possible");
            return;
        }

        int[][] ans = new int[arr1.length][arr1[0].length];
        for (int i=0;i<arr1.length;i++){
            for (int j=0;j<arr1[0].length;j++){
                ans[i][j] = arr1[i][j] + arr2[i][j];
            }
        }

        for (int i=0;i<arr1.length;i++){
            for (int j=0;j<arr1[0].length;j++){
                System.out.print(ans[i][j]+" ");
            }
            System.out.println();
        }

    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the dimension of arrays");
        System.out.print("Row=");
        int R = sc.nextInt();

        System.out.print("Column=");
        int C = sc.nextInt();
        System.out.println();

        int[][] arr1 = new int[R][C];
        System.out.println("Enter the first matrix");
        for (int i=0;i<arr1.length;i++){
            for (int j=0;j<arr1[0].length;j++){
                arr1[i][j] = sc.nextInt();
            }
        }

        int[][] arr2 = new int[R][C];
        System.out.println("Enter the second matrix");
        for (int i=0;i<arr2.length;i++){
            for (int j=0;j<arr2[0].length;j++){
                arr2[i][j] = sc.nextInt();
            }
        }

        Sum(arr1,arr2);

    }
}