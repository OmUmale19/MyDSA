package SinglyLinkedList;

public class part2 {
    public static class node{
        int data;
        node next;
        public node(int data){
            this.data = data;
        }
    }
    public static void display(node head){   // here head ref variable will point to actual head
        while (head !=null){
            System.out.print(head.data+" ");
            head = head.next;
        }
    }

    // Display using recursion
    public static void display1(node head){
        if (head == null){
            return;
        }
        System.out.print(head.data+" ");
        display1(head.next);
    }

    // Reverse linked list
    public static void reverse(node head){
        if (head == null) return;
        reverse(head.next);
        System.out.print(head.data +" ");
    }
    public static void main(String[] args) {

        // Creating a node
        node a1 = new node(5);   // head node
        node b1 = new node(8);
        node c1 = new node(9);
        node d1 = new node(6);
        node e1 = new node(11);  // tail node

        // Link the node
        a1.next = b1;
        b1.next = c1;
        c1.next = d1;
        d1.next = e1;

        // Display Linked List
        node temp =a1;   // Head
        while (temp != null){
            System.out.print(temp.data+" ");
            temp =  temp.next;
        }
        // Here head will be lost
        // Hence we use display function
        System.out.println();
        System.out.println("_________________________");
        while (temp != null){
            System.out.print(temp.data+" ");
            temp =  temp.next;
        }
        // Head lost - no linked list printed
        System.out.println();
        System.out.println("_________________________");

        // Using display function
        display(a1);
        // here no loss of head
        System.out.println();
        System.out.println("_________________________");
        display(a1);

        System.out.println();
        System.out.println("_________________________");
        //Display using recursion
        display1(a1);

        System.out.println();
        System.out.println("_________________________");
        // Reverse using recursion
        reverse(a1);
    }
}
