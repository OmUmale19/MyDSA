// Frog jump min cost

import java.util.Scanner;

public class Frog1 {

    static int MinCost(int[] h,int n,int idx){

        // Base case
        if (idx == n-1){
            return 0;
        }

        // from idx+1 index
        int x = Math.abs(h[idx]-h[idx+1])+ MinCost(h,n,idx+1);
        if(idx == n-2){     // At n-2 index no option for 2 jump
            return x;
        }

        // from idx+2
        int y = Math.abs(h[idx]-h[idx+2])+ MinCost(h,n,idx+2);

        return Math.min(x,y);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of height array");
        int n = sc.nextInt();

        int[] h = new int[n];
        System.out.println("---------------");
        for (int i=0;i<h.length;i++){
            h[i] = sc.nextInt();
        }
        System.out.println("---------------");

        System.out.println("Min cost is "+MinCost(h,n,0));
    }
}