package Searching.Tester;
// Given a 2D matrix and target
// every row is sorted in (L to R)
// 1st elem of each row is greater than last elem of previous row

import java.util.Scanner;

public class BS_Matrix {

    static void BS(int[][] arr,int target){
        int r = arr.length;
        int c = arr[0].length;

        // Time comp - O(n2)
//        for (int i=0;i<r-1;i++){
//            if (target>=arr[i][0] && target<arr[i+1][0]){
//                for (int j=0;j<c;j++){
//                    if (arr[i][j]==target){
//                        System.out.println("Target found at "+i+" "+j);
//                        return;
//                    }
//                }
//            }
//        }
//        System.out.println("Target not found");

        for (int i=0;i<r-1;i++){
            if (target>=arr[i][0] && target<arr[i+1][0]){

            }
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of matrix");
        int r = sc.nextInt();
        int c = sc.nextInt();

        int[][] arr = new int[r][c];
        System.out.println("Enter the elements in matrix");
        for (int i=0;i<r;i++){
            for (int j=0;j<c;j++){
                arr[i][j] = sc.nextInt();
            }
        }
        System.out.println("Enter the target");
        int target = sc.nextInt();
        BS(arr,target);
    }
}
