import java.util.Arrays;
import java.util.Scanner;

public class Main {

    static void printArray(int[] arr){
        for (int i=0;i<arr.length;i++) {
            System.out.print(arr[i]+" ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array");
        int n = sc.nextInt();
        int[] arr = new int[n];

        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
        printArray(arr);
        System.out.println();

//        // Shallow coping
//        int[] arr2 = arr;
//        arr2[0] = 0;   // Changing values of arr2
//        arr2[1] = 1;
//
//        System.out.println("Original array");
//        printArray(arr);
//        System.out.println();
//        System.out.println("Copied array");
//        printArray(arr2);
//        // The above steps are shallow coping


//        // Array Cloning
//        int[] arr3 = arr.clone();
//        arr3[0] = 0;
//        arr3[1] = 1;
//        printArray(arr);
//        printArray(arr3);
//        // Deep coping
//
//
        int[] arr4 = Arrays.copyOf(arr,arr.length);
        arr4[0] = 0;
        arr4[1] = 0;
        printArray(arr);
        printArray(arr4);

        int[] arr5 = Arrays.copyOf(arr,3);   //Arrays class has inbuilt methods
        printArray(arr5);

        int[] arr6 = Arrays.copyOfRange(arr,1,4); // Here 'from:' index is inclusive "[" and 'to:' index is exclusive ")"
        printArray(arr6);


    }
}