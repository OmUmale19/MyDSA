// Immutability of strings

import java.util.Scanner;

public class Immulability {

    public static void main(String[] args) {
        // Interning in a string
        String s1 = "Hello";
        String s2 = "Hello";
        s2 += "Dello";
        System.out.println(s1);
        System.out.println(s2);

        // New in string
        String s3 = new String("Hiafa");
        String s4 = new String("Haafa");
        s3 += s4;
        System.out.println(s3+"   "+s4);

        // Immutability in strings
        String s5 = "Hii this is OM";
//        s5.charAt(6) = 'G';
        s5 = s5 + "My name";
        System.out.println( s5.charAt(5));
        System.out.println( s5);

    }
}
