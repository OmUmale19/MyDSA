package Searching;

import java.util.Scanner;

public class BinarySearch {

    static void BS(int[] arr,int s,int e,int target){

        if (s>e){
            return;
        }
            int mid = s+(e-s)/2;
            if (target == arr[mid]){
                System.out.println("target found at index: "+mid);
                return ;
            }
            else if (target<arr[mid]){
                e = mid -1;
            }
            else {
                s = mid+1;
            }
        System.out.println("Target not found");
    }

    static boolean BS1(int[] arr,int s,int e,int target){

        if (s>e){
            return false;
        }
        int mid = s+(e-s)/2 ;

        if (arr[mid] == target){
            return true;
        }
        else if (target <arr[mid]) {
            return BS1(arr,s,mid-1,target);
        }
        else {
            return BS1(arr,mid+1,e,target);
        }

    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array");
        int n = sc.nextInt();
        System.out.println("Enter the elements of array");
        int[] arr = new int[n];
        for (int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("Enter the target");
        int target = sc.nextInt();
        BS(arr,0,n-1,target);
        System.out.println("__________________________");
        System.out.println(BS1(arr,0,n-1,target));;
    }
}
