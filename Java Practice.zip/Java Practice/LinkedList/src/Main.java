
public class Main {
    public static class node{
        int data;
        node next;
        public node(int data){
            this.data = data;
        }
    }
    public static void main(String[] args) {
        node a = new node(3);
        System.out.println(a);
    }
}