import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        while (1!=0) {
            System.out.println("Enter the choice.......");
            System.out.println("1] Binary to Decimal");
            System.out.println("2] Decimal to Binary");
            int a = sc.nextInt();
            switch (a) {

                case 1: {
                    System.out.println("Enter the binary:");
                    int binary = sc.nextInt();
                    int ans1 = 0;  // Output of Binary in decimal
                    int power1 = 1; //Power is 1 as 2^0=1

                    while (binary > 0) {
                        int unit_digit = binary % 10;   //To find the unit digit
                        ans1 += (unit_digit * power1);    // To add the previous ans and multiplication of unit digit & power[ ex. 1*2^1]
                        binary /= 10;                   // To covert binary no. into with 1 dec place so that for next cycle the unit digt will the previous of unit  digit
                        power1 *= 2;                     // To increment power by 2
                    }
                    System.out.println("The Decimal no:" + ans1);
                    break;
                }

                case 2: {
                    System.out.println("Enter the Decimal:");
                    int decimal = sc.nextInt();
                    int ans2 = 0;
                    int power2 = 1;              //Power is 1 as 10^0=1
                    while (decimal > 0) {
                        int parity = decimal % 2;    //To find the parity bit whether 0 or 1
                        ans2 += (parity * power2);
                        power2 *= 10;
                        decimal /= 2;      // Algorithm and dry run in book
                    }
                    System.out.println("The binary no:" + ans2);
                    break;
                }

                default:
                    System.out.println("Invalid Option");
            }
        }
    }
}