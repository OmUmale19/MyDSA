package Practice_Questions;
// Check if the string is balanced or Valid Parenthesis
// Input - (())()  Output - True
// Input - )()(()))  Output - False

import java.util.Scanner;
import java.util.Stack;

public class Quest1 {

    static int size =0;
    static boolean valid(String s){
        Stack<Character> st  = new Stack<>();
        for(char ch : s.toCharArray()){
            if(ch =='('){
                st.push(ch);
                size++;
            }
            else {
                if(st.isEmpty()){
                    return false;
                }
                else {
                    st.pop();
                    size--;
                }
            }
        }
        if (st.isEmpty()) return true;
        return false;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        System.out.println(valid(s));
        System.out.println(size);
    }
}
