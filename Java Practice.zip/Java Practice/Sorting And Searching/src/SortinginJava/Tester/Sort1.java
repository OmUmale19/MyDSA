package SortinginJava.Tester;
// Given almost sorted array only one pair swapped
// 3,8,6,7,5,9,10

import java.util.Arrays;
import java.util.Scanner;

public class Sort1 {

    static void sort(int[] arr){
        int greater = -1;
        int smaller = -1;

        // Edge case
        if (arr.length <=1){
            return;
        }

        for (int i=1;i<arr.length;i++){
            if (arr[i-1]>arr[i]){
                if (greater == -1){
                    greater = i-1;
                    smaller = i;
                }
                else{
                    smaller = i;
                }
            }
        }
        int tmp = arr[greater];
        arr[greater] = arr[smaller];
        arr[smaller] = tmp;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        int n = sc.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter the elements in array:");
        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
        sort(arr);
        System.out.println(Arrays.toString(arr));
    }
}
