import java.util.Scanner;

/* Pascal's Triangle using jagged array */
public class Ques3 {
    static void printMatrix(int[][] mat){  // use to print jagged array
        for (int i=0;i<mat.length;i++){
            for (int j=0;j<mat[i].length;j++){
                System.out.print(mat[i][j]+" ");
            }
            System.out.println();
        }
    }

    static void PascalsT(int n){
        int[][] ans = new int[n][];

        for (int i=0;i<n;i++){
            // Each ith row has i+1 columns
            ans[i] = new int[i+1];
            for (int j=0;j<=i;j++){

                if (j==0 || i==j){
                    ans[i][j] = 1;
                }
                else {
                    ans[i][j] = ans[i-1][j-1] + ans[i-1][j];
                }
            }
        }
        printMatrix(ans);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the value of n");
        int n = sc.nextInt();

        PascalsT(n);
    }
}
