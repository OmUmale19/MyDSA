package DoublyLinkedList;

public class part1 {

    // Node for doubly linked list
    public static class node {
        int data;
        node next;
        node prev;
        public node(int data){
            this.data = data;
        }
    }

    public static void display(node head){   //display from head
        node temp = head;
        while (temp!= null){
            System.out.print(temp.data+" ");
            temp = temp.next;
        }
        System.out.println();
    }

    public static void displayRev(node tail){   // Display from tail - reverse
        node temp = tail;
        while (temp != null){
            System.out.print(temp.data+" ");
            temp = temp.prev;
        }
        System.out.println();
    }

    public static void displayRan(node random){   // Display back from random node
        node temp = random;
        while (temp != null){
            System.out.print(temp.data+" ");
            temp = temp.prev;
        }
        System.out.println();
    }
    public static void main(String[] args) {
        node a = new node(5);
        node b = new node(6);
        node c = new node(1);
        node d = new node(9);
        node e = new node(7);
        node f = new node(3);

        a.prev = null;
        a.next = b;

        b.prev = a;
        b.next = c;

        c.prev = b;
        c.next = d;

        d.prev = c;
        d.next = e;

        e.prev = d;
        e.next = f;

        f.prev = e;
        f.next = null;

        display(a);
        displayRev(f);
        displayRan(d);
        System.out.println(c.prev.data);  // Can access the previous node



    }
}
