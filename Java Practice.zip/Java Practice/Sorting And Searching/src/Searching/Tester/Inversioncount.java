package Searching.Tester;

import java.util.Arrays;
import java.util.Scanner;

public class Inversioncount {

    static int merge(int[] arr,int s,int mid,int e){
        int Ic1 =0;
        int Ic2 =0;
        int n1 = mid-s+1;
        int n2 = e-mid;
        int[] left = new int[n1];
        int[] right = new int[n2];
        for (int i=0;i<n1;i++){
            left[i] = arr[s+i];
        }
        for (int j=0;j<n2;j++){
            right[j] = arr[mid+1+j];
        }
        int i=0,j=0,k=s;
        while (i<n1 && j<n2){
            if (left[i]<right[j]){
                arr[k++] = left[i++];
            }
            else if (left[i]<right[j] && left[i]>right[j-1]){
                arr[k++] = left[i++];
                Ic1++;
            }
            else {
                arr[k++] = right[j++];
                Ic2++;
            }
        }

        while (i<n1){
            arr[k++] = left[i++]; Ic1++;
        }
        while (j<n2){
            arr[k++] = right[j++];
        }
        return Ic1 + Ic2;
    }
    static int cnt(int[] arr,int s,int e){
        int n=0;
        if (s<e) {
            int mid = (s + e) / 2;
            cnt(arr, s, mid);
            cnt(arr, mid + 1, e);
            n += merge(arr, s, mid, e);
        }
        return n ;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array");
        int n = sc.nextInt();
        System.out.println("Enter the elements of array");
        int[] arr = new int[n];
        for (int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println(cnt(arr,0,n-1));
        System.out.println(Arrays.toString(arr));
    }
}
