package SortinginJava;

import java.util.Scanner;

public class Kth_smallest {

    static int kthsmallest(int[] arr,int s,int e,int k){
        if (s<=e){
            int p = part(arr,s,e);

            if (p == k){
                return arr[p];
            }
            if (k<p){
                return kthsmallest(arr,s,p-1,k);
            }
            else {
               return kthsmallest(arr,p+1,e,k);
            }
        }
        return -1;
    }
    static int part(int[] arr,int s,int e){
        int pivot = arr[e];
        int p = s;

        for (int i=s;i<e;i++){
            if (arr[i]<pivot){
                 int temp = arr[i];
                arr[i] = arr[p];
                arr[p] =temp;
                p++;
            }
        }
        int temp = arr[p];
        arr[p] = arr[e];
        arr[e] = temp;
        return p;
    }

    public static void main(String[] args) {
        Scanner sc =  new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];

        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        int k = sc.nextInt();
        System.out.println(kthsmallest(arr,0,n-1,k-1));
    }
}
