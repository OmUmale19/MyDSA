package SortinginJava.Tester;
// Sort all 0s,1s and 2s

import java.util.Arrays;
import java.util.Scanner;

public class SortZeroOneTwo {   // Brute force approach
    static void sort(int[] arr){
        int c0=0,c1=0,c2=0;

        for (int i=0;i<arr.length;i++){
            if (arr[i]==0){
                c0++;
            }
            else if (arr[i]==1) {
               c1++;
            }
            else {
                c2++;
            }
        }
        int i=0;
        while (c0>0){
            arr[i++] =0;
            c0--;
        }
        while (c1>0){
            arr[i++] =1;
            c1--;
        }
        while (c2>0){
            arr[i++] =2;
            c2--;
        }
    }

    static void sort1(int[] arr){    // 3-pointer approach
        int n = arr.length;
        int low=0;
        int mid=0;
        int high=n-1;

        while (mid<=high){
            if (arr[mid]==0){
                int temp =arr[low];
                arr[low]=arr[mid];
                arr[mid] = temp;
                low++;
                mid++;
            }
            if (arr[mid]==1){
              mid++;
            }
            if (arr[mid]==2){
                int temp =arr[high];
                arr[high]=arr[mid];
                arr[mid] = temp;
                high--;
            }
        }

    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        int n = sc.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter the elements in array:");
        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
        sort(arr);
        System.out.println(Arrays.toString(arr));
        System.out.println("-----------------------");
        sort1(arr);
        System.out.println(Arrays.toString(arr));
    }
}
