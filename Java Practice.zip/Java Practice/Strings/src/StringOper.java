import java.util.*;

public class StringOper {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = "abc";
        System.out.println(str);
        System.out.println("----------------");

        // add property - string
        str += "pqr";
        System.out.println(str);
        System.out.println("---------------");

        // add property - char
        str +='M';
        System.out.println(str);
        System.out.println("---------------");

        // add property - int
        str += 10;
        System.out.println(str);
        // Imp - order from left to right
        System.out.println(str+10);
        //Imp order
        System.out.println("hii"+"my"+'M'+20+30);
        System.out.println("hii"+"my"+'M'+(20+30));
        System.out.println(20+30+"hii"+"my"+'M');




    }
}
