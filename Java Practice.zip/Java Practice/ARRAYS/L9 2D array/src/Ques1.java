/* Given matrix, two co-ordinates (l1,r1) and (l2,r2) given
* Return sum of rectangle  */

import java.util.Scanner;

class Operation{

    static int RectangleSum(int[][] mat,int l1,int r1,int l2,int r2){  // Brute Force method
        int sum =0;
        for (int i=l1;i<=l2;i++){
            for (int j=r1;j<=r2;j++){
                sum += mat[i][j];
            }
        }
        return sum;
    } 
}
public class Ques1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the row and column of matrix");
        int r = sc.nextInt();
        int c = sc.nextInt();

        int[][] mat = new int[r][c];
        System.out.println("Enter the elements in matrix");
        for(int i=0;i<mat.length;i++){
            for (int j=0;j<mat[0].length;j++){
                mat[i][j] = sc.nextInt();
            }
        }

        System.out.println("Enter the 1st coordinates:(l1,r1)");
        int l1 = sc.nextInt();
        int r1 = sc.nextInt();

        System.out.println("Enter the 2nd coordinates:(l2,r2)");
        int l2 = sc.nextInt();
        int r2 = sc.nextInt();

        System.out.println("Sum: "+ Operation.RectangleSum(mat,l1,r1,l2,r2));

    }
}