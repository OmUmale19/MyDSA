import java.util.Stack;

public class Intro {
    static Stack<Integer> reverse(Stack<Integer> st){
        Stack<Integer> rev = new Stack<>();
        while (st.size()>0){
            rev.push(st.peek());
            st.pop();
        }
        return rev;
    }
    static Stack<Integer> copy(Stack<Integer> st){
        Stack<Integer> rev = new Stack<>();
        Stack<Integer> cp = new Stack<>();
        while (st.size()>0){
            rev.push(st.pop());
        }
        while (rev.size()>0){
            cp.push(rev.pop());
        }
        return cp;
    }
    public static void main(String[] args) {

        // Inbuilt stack function
        Stack<Integer> st = new Stack<>();

        System.out.println(st.isEmpty());

        st.push(5); // Insert into stack
        st.push(6);
        st.push(1);
        st.push(3);
        st.push(8);
        st.push(7);
        st.push(9);

        // LIFO see top most element
        System.out.println(st.peek());

        //Print all stack
        System.out.println(st);

        //delete element LIFO
        st.pop();
        System.out.println(st);

        // Size of stack
        System.out.println("Size :"+st.size());

        // isEmpty boolean value for stack filled or not
        System.out.println(st.isEmpty());

        // Copy the stack
        System.out.println(copy(st));

        // Reverse the stack;
        st.push(5); // Insert into stack
        st.push(6);
        st.push(1);
        st.push(3);
        st.push(8);
        st.push(7);
        System.out.println(reverse(st));


    }
}