package Searching.Tester;

import java.util.Scanner;
// Given a rotated sorted array - a[4,5,6,7,1,2,3]  output = 4
// Logic of Binary search used 2 sorted parts-
// 1. left sorted part where all elements are greater than a[n-1]
// 2. Right sorted part where all elements are less than a[n-1] and its starting idx is min

public class RotatedArr1 {
    static int MinIdx(int[] arr){
        int minIdx=-1;
        int n = arr.length;
        int s = 0;
        int e = n-1;

        while (s<=e){
            int mid = s+(e-s)/2;

            if(arr[mid]<=arr[n-1]){
                minIdx = mid;
                e = mid-1;
            }
            else {
                s = mid+1;
            }
        }
        return minIdx;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        int n = sc.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter the elements in array:");
        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println(MinIdx(arr));
    }
}
