package SortinginJava.Tester;

// Given Arr- [2,3,5,5,5,6,7]   target=5     Output=2
// Logic of binary search

import java.util.Arrays;
import java.util.Scanner;

public class FirstOcc {   // TC-O(n)
    static int[] FO1(int[] arr,int target){
        int loop=0;
        for (int i=0;i<arr.length;i++){
            loop++;
            if (arr[i]==target){
                return new int[]{i,loop};
            }
        }
        return new int[]{-1,loop};
    }

    static int[] FO2(int[] arr,int s,int e,int target){
        int n = arr.length;
        int FO = -1;  // First Occ
        int loop =0;
        while (s<=e){
            loop++;
            int mid = s+(e-s)/2;
            if (target==arr[mid]){
                FO = mid;
                e = mid-1;
            }
            else if (target<arr[mid]) {
                e = mid-1;
            }
            else {
                s = mid+1;
            }
        }
        return new int[]{FO,loop};
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        int n = sc.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter the elements in array:");
        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
        int target = sc.nextInt();

        System.out.println(Arrays.toString(FO1(arr,target)));
        System.out.println("-----------------------");
        System.out.println(Arrays.toString(FO2(arr,0,n-1,target)));
    }
}
