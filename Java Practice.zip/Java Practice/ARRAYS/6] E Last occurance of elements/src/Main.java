/* Find the last occurance of target element in an array i.e. the last index(max index) at which the
* element is present*/

import java.util.Scanner;
class Arraylast{

    int LastOcc(int[] arr,int target){
        int lastocc = -1;       // Because if elem doesn't exist it will return no index
        for (int i=0;i<arr.length;i++){
            if (arr[i] == target){
                lastocc = i;
            }
        }
        return lastocc;
    }

}
public class Main {

    public static void main(String[] args) {
        System.out.println("Enter the size of array:");
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        int[] arr = new int[x];

        System.out.println("Enter the elements of array");
        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("Enter the number whose last occurance to be found");
        int target= sc.nextInt();

        Arraylast obj = new Arraylast();

        System.out.println("The last index of "+target+" element is: "+obj.LastOcc(arr,target));

    }
}