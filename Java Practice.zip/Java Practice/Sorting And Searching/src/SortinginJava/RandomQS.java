package SortinginJava;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class RandomQS {
    static int random(int[] arr,int s,int e){
        Random randn = new Random();
        int r = s + randn.nextInt(e - s);
        return r;
    }
    static void RQS(int[] arr,int s,int e){
        int n = arr.length;
        if (s<e){
            int r = random(arr,s,e);
            int temp = arr[r];
            arr[r] = arr[e];
            arr[e] = temp;
            int p = part(arr,s,e);
            RQS(arr,s,p-1);
            RQS(arr,p+1,e);
        }
    }
    static int part(int[] arr,int s,int e){
        int n =  arr.length;
        int pivot = arr[e];
        int p =s;   // p - partition index

        for (int i=s;i<e;i++){
            if (arr[i]<pivot){
                int temp = arr[i];
                arr[i] = arr[p];
                arr[p] = temp;
                p++;
            }
        }
        int temp =arr[p];
        arr[p] = arr[e];
        arr[e] = temp;
        return p;
    }
    public static void main(String[] args) {
        Scanner sc =  new Scanner(System.in);
        System.out.println("Enter the size of array");
        int n = sc.nextInt();
        System.out.println("Enter the elements of array");
        int[] arr = new int[n];

        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        RQS(arr,0,n-1);
        System.out.println("Sorted array");
        System.out.println(Arrays.toString(arr));
    }
}
