// Strings basics

import java.util.Scanner;

public class Basics {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Scanner n = new Scanner(System.in);

//        // Input Output
//        String s1 = sc.next();
//        System.out.println(s1);
//        String s2 = n.nextLine();
//        System.out.println(s2);
//        System.out.println("-------------------");
//
//        // Length function - In array no braces cause String is a class
//        System.out.println(s1.length());
//        System.out.println(s2.length());
//        System.out.println("-------------------");
//
//        // CharAt() function
//        System.out.println(s1.charAt(2));
//        System.out.println(s2.charAt(3));
//        System.out.println("-------------------");
//
//        // indexOf() function
//        System.out.println(s1.indexOf('m'));
//        System.out.println(s2.indexOf('o'));
//        System.out.println("-------------------");
//
//        // compareTo() - Lexicographic order (a,b,c,d...)
//        System.out.println(s1.compareTo(s2));

        // contains() - If it have string
        String str = "Hello this is om";
        System.out.println(str.contains("m"));
        System.out.println("-------------------");
        // startsWith() and endsWith()
        System.out.println(str.startsWith("Hel"));
        System.out.println(str.startsWith("Hello this"));
        System.out.println(str.startsWith("h"));
        System.out.println("-------------------");
        System.out.println(str.endsWith("om"));
        System.out.println(str.endsWith("o"));
        System.out.println(str.endsWith("m"));

        // toLowerCase() and toUpperCase()
        System.out.println("-------------------");
        System.out.println(str.toLowerCase());
        System.out.println(str.toUpperCase());

        // Concatenation of two strings
        System.out.println("---------------------");
        String str1 ="Hello";
        String str2 ="World";
        String str3 = str1.concat(str2);
        System.out.println(str3);
        System.out.println(str2.concat(str1));

        //




    }
}