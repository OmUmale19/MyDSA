package Practice_Questions;

import java.util.Arrays;
import java.util.Scanner;
import java.util.Stack;

// Given a stock price array
// [100,80,60,70,60,75,85]
// Return the span where ith price is the maximum
// [1,1,1,2,1,4,6]
public class Stock_Span {

    static int[] stockSpan(int[] arr){
        int[] res = new int[arr.length];
        Stack<Integer> st = new Stack<>();
        st.push(0);   // We will play with indices
        res[0] = 1;   // First elem is max for only 1 day

        for(int i=1;i<arr.length;i++){
            while (st.size()>0 && arr[st.peek()]<arr[i]){
                st.pop();
            }
            if (st.size()==0) res[i] =1;
            else res[i] = i-st.peek();
            st.push(i);
        }
        return res;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of days:");
        int[] arr = new int[sc.nextInt()];
        for(int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println(Arrays.toString(stockSpan(arr)));
    }
}
