package SinglyLinkedList;

public class Ques1 {
    // Length of linked list
    public static int length(part2.node head){
        int count =0;
        while (head !=null){
            count++;
            head = head.next;
        }
        return count;
    }
    public static void main(String[] args) {
        // Creating a node
        part2.node a1 = new part2.node(5);   // head node
        part2.node b1 = new part2.node(8);
        part2.node c1 = new part2.node(9);
        part2.node d1 = new part2.node(6);
        part2.node e1 = new part2.node(8);
        part2.node f1 = new part2.node(64);
        part2.node g1 = new part2.node(62);
        part2.node h1 = new part2.node(11);  // tail node

        // Link the node
        a1.next = b1;
        b1.next = c1;
        c1.next = d1;
        d1.next = e1;
        e1.next = f1;
        f1.next = g1;
        g1.next = h1;

        System.out.println();
        part2.display(a1);
        System.out.println();
        System.out.println("__________________________");

        // Length of LL
        System.out.println("Length ->"+length(a1));
    }
}
