package SortinginJava.Tester;


import java.util.Arrays;

public class Lexicographic {

    static void sort(String[] fruits){
        int n = fruits.length;

        for (int i=0;i<n;i++){
            int min_idx =i;
            for (int j=i+1;j<n;j++){
                if (fruits[j].compareTo(fruits[min_idx])<0){
                    min_idx = j;
                }
            }
            //swap
            String temp = fruits[i];
            fruits[i]= fruits[min_idx];
            fruits[min_idx] = temp;
        }
    }
    public static void main(String[] args) {
        String[] fruits ={"apple","kiwi","mango","pappya","watermelon","lime","strawberry"};
        String[] veggi = {"tomato","potato","spinach","ginger","garlic","brinjal","broklie"};
        sort(veggi);
        System.out.println(Arrays.toString(veggi));
    }
}
