package Advance_Que_on_Stack;

import java.util.Stack;

public class INFIX {

    static int priority(char ch){
        if(ch=='+') return 1;
        else if(ch=='-') return 1;
        else if(ch=='*') return 2;
        else return 2;
    }

    static int operation(int v1,int v2, char operator){
        if (operator=='+') return v1+v2;
        else if(operator=='-') return v1-v2;
        else if(operator=='*') return v1*v2;
        else return v1/v2;
    }

    static void infix(String s){
        int n = s.length();
        Stack<Integer> val = new Stack<>();  // Value stack
        Stack<Character> ope = new Stack<>(); // Operator stack

        for(int i=0;i<n;i++){
            char ch = s.charAt(i);

            // if "(" direct push
            if(ch=='(') ope.push(ch);

            // if ch is a digit
            else if(Character.isDigit(ch)) val.push(ch-'0');
//            else if(ch>='0' && ch<='9') val.push(ch-'0');

            // if we get this ')' perform all operations
            else if(ch==')'){
                // Until we found open bracket
                while (ope.peek()!='('){
                    int v2 = val.pop();
                    int v1 = val.pop();
                    char operator = ope.pop();
                    int result = operation(v1,v2,operator);
                    val.push(result);
                }
                // pop the opening bracket as ope.peek()==(
                ope.pop();
            }
            else if(ch=='+' || ch=='-' || ch=='*' || ch=='/'){
                while (ope.size()>0 && ope.peek()!='(' &&
                       priority(ch) <= priority(ope.peek())){
                    int v2 = val.pop();
                    int v1 = val.pop();
                    char operator = ope.pop();
                    int result = operation(v1,v2,operator);
                    val.push(result);
                }
                ope.push(ch);
            }
        }
        // If the ope stack is not empty then perform all operations
        while (ope.size()>0){
            int v2 = val.pop();
            int v1 = val.pop();
            char operator = ope.pop();
            int result = operation(v1,v2,operator);
            val.push(result);
        }
        System.out.println(val.peek());
    }
    public static void main(String[] args) {
        String s = "2+(5-3*6/2)";
        infix(s);
    }
}
