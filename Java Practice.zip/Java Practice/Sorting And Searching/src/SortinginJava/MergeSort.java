package SortinginJava;

import java.util.Arrays;
import java.util.Scanner;

public class MergeSort {
    static void merge(int[] arr,int s,int mid,int e){
        int n1 = mid-s+1;
        int n2 = e-mid;
        int[] left = new int[n1];
        int[] right = new int[n2];
        for (int i=0;i<n1;i++){
            left[i] = arr[s+i];
        }
        for (int j=0;j<n2;j++){
            right[j] = arr[mid+1+j];
        }
        int i=0,j=0,k=s;
        while (i<n1 && j<n2){
            if (left[i]<right[j]){
                arr[k++] = left[i++];
            }
            else {
                arr[k++] = right[j++];
            }
        }
        while (i<n1){
            arr[k++] = left[i++];
        }
        while (j<n2){
            arr[k++] = right[j++];
        }
    }
    static void mergesort(int[] arr,int s,int e){
        if (s>=e) return;
        int mid = (s+e)/2;
        mergesort(arr,s,mid);
        mergesort(arr,mid+1,e);
        merge(arr,s,mid,e);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        int n = sc.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter the elements in array:");
        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
        mergesort(arr,0,n-1);
        System.out.println(Arrays.toString(arr));
    }
}