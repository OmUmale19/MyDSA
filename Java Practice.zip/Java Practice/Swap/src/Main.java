//  Swap the two integers a and b

import java.util.Scanner;

class Swap{

    static void UsingTemp(int a,int b){
        System.out.println("Original values:");
        System.out.println("a: "+a);
        System.out.println("b: "+b);
        int temp;
        temp = a;       // a ki value temp me store ho gayi
        a = b;         // b ki value a me store ho gayi
        b = temp;      // temp ki value b me store ho gayi
        System.out.println("Swapped values:");
        System.out.println("a: "+a);
        System.out.println("b: "+b);
    }

    static void UsingSumDiff(int a,int b){
        System.out.println("Original values:");
        System.out.println("a: "+a);
        System.out.println("b: "+b);

        a = a+b;
        b = a-b;
        a = a-b;

        System.out.println("Swapped values:");
        System.out.println("a: "+a);
        System.out.println("b: "+b);

    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc  = new Scanner(System.in);
        System.out.println("Enter the values of a and b:");
        int a = sc.nextInt();
        int b= sc.nextInt();

        Swap.UsingTemp(a,b);
        Swap.UsingSumDiff(a,b);

    }
}