package Searching.Tester;

import java.util.Scanner;
// Given sorted rotated array - a[4,5,6,7,1,2,3]   target = 5
// Give the index
// Logic use BS. check two parts - from [s to mid] and from [mid to end]
// check in that part

public class RotatedArr2 {
    
    static int Search(int[] arr,int target){
        int n = arr.length;
        int s = 0,e=n-1;
        int ans = -1;

        while (s<=e){
            int mid = s+(e-s)/2;

            if (arr[mid]==target){
                return mid;
            }
            else if (arr[mid]<arr[e]) {      // mid to end sorted
                if (target>arr[mid] && target<=arr[e]){   // Check if target lie between mid and end
                    s = mid+1;
                }
                else {
                    e = mid-1;
                }
            }

            else {    // start to mid sorted
                if (target>=arr[s] && target<arr[mid]){   // Check if it lie between start and mid
                    e = mid-1;
                }
                else {
                    s = mid+1;
                }
            }
        }
        return -1;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        int n = sc.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter the elements in array:");
        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
        while (true) {
            System.out.println("Enter the target");
            int target = sc.nextInt();
            System.out.println("Search :" + Search(arr, target));
        }
    }
}
