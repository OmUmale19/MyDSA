package Practice_Questions;
// Find the previous Greater element of the array
// ex -  [100,80,60,70,60,75,85]
// ans - [-1,100,80,80,70,60,80,100]

import java.util.Arrays;
import java.util.Scanner;
import java.util.Stack;

public class Quest3_Part2 {

    static int[] prevGreater(int[] arr){
        int n = arr.length;
        int[] res = new int[n];
        Stack<Integer> st = new Stack<>();
        res[0] = -1;
        st.push(arr[0]);

        for(int i=1;i<n;i++){
            while(st.peek()<arr[i]){
                st.pop();
            }
            if (st.size()==0) res[i] = -1;
            else res[i] = st.peek();
            st.push(arr[i]);
        }
        return res;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println(Arrays.toString(prevGreater(arr)));
    }
}
