public class Max {
    static int max(int[] arr,int index){   // index is current
        if(index == arr.length-1){
            return arr[index];
        }
        int smallAns = max(arr,index+1);
        return Math.max(smallAns,arr[index]);
    }
    public static void main(String[] args) {
        int[] Arr = {3,1};
        System.out.println(max(Arr,0));
    }
}
