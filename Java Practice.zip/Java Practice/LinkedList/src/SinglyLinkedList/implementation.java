package SinglyLinkedList;

import org.w3c.dom.Node;

import java.util.Scanner;

public class implementation {

    public static class node{
        int data;
        node next;
        public node(int data){
            this.data = data;
        }
    }
    public static class LL{   // Class linked list as a data structure
        node head;
        node tail;
        int size;   // To make T.C - O(1)

        // Insert at an end
        void insertAtEnd(int val){   // O(1)
            node temp = new node(val);
            if (head == null){  // Empty LL
                head = temp;
                tail = temp;
            }
            else {      // not empty
                tail.next = temp;
                tail = temp;
            }
            size++;    // to increase the size by 1
        }

        // Insert at start
        void insertAtstart(int val){     // O(1)
            node temp = new node(val);
            if (head==null){
                head = tail = temp;
            }
            else {
                temp.next = head;
                head = temp;
            }
            size++;    // to increase the size by 1
        }

        // Insert at index
        void insertAtIdx(int val,int idx){  // O(n) but S.C-> O(1)
            node temp = head;

            if (idx==size){
                insertAtEnd(val);;
                return;
            }
            else if (idx==0) {
                insertAtstart(val);
                return;
            }
            else if (idx<0 || idx>size()) {
                System.out.println("Wrong index");
                return;
            }
            node t = new node(val);
            for (int i=0;i<idx-1;i++){   // Traveling to previous index
                temp = temp.next;
            }
            t.next = temp.next;
            temp.next = t;
            size++;    // to increase the size by 1
        }

        // get element at index
        int getAtIdx(int idx){    // O(n)  * limitation *
            node temp = head;

            if (idx<0 || idx>size()){
                return -1;
            }
            for (int i=0;i<idx;i++){
                temp = temp.next;
            }
            return temp.data;
        }

        // delete at index
        void deleteAtIdx(int idx){
            if (idx==0){
                head = head.next;
                return;
            }
            node temp = head;
            for (int i=0;i<idx-1;i++){
                temp = temp.next;
            }
            temp.next = temp.next.next;
            if (idx == size-1){
                tail = temp;
            }
            size--;
        }
        int size(){   // O(n) but not needed
            node temp = head;
            int count =0;
            while (temp !=null){
                count++;
                temp = temp.next;
            }
            return count;
        }

        void display(){   // to maintain head  // O(n)
            node temp = head;
            while (temp !=null){
                System.out.print(temp.data+" ");
                temp = temp.next;
            }
            System.out.println();
        }

        void middle(node head){
            node s = head;
            node f = head;
            int cnt = 0;
            while (f.next!=null && f.next.next!=null){
                s = s.next;
                f = f.next.next;
                cnt++;
            }
            if (cnt%2==0){
                System.out.println(s.data);
            }
            else {
                System.out.println(s.next.data);
            }
        }


    }
    public static void main(String[] args) {
        LL link = new LL();   // Linked list -> link is created
        System.out.println(link.head);
        System.out.println(link.tail);

        // adding node
        Scanner sc = new Scanner(System.in);

        link.insertAtEnd(1);
        link.insertAtEnd(2);
        link.insertAtEnd(3);
        link.insertAtEnd(4);
        link.insertAtEnd(5);

        link.display();
        System.out.println("Size ->"+link.size());
        System.out.println("_________________________");

        //New insert at start
        link.insertAtstart(88);
        link.display();
        System.out.println("Size ->"+link.size());
        System.out.println("_________________________");

        link.insertAtIdx(54,3);
        link.display();
        link.size();
        System.out.println("_________________________");

        link.insertAtIdx(99,0);
        link.insertAtIdx(42,8);
        link.display();
//        System.out.println(link.head.data+" "+link.tail.data);
        System.out.println(link.getAtIdx(5));
        System.out.println("-------------------------");

        link.deleteAtIdx(3);
        link.display();
        System.out.println(link.size);


        System.out.println("_____________________________________________");
        link.middle(link.head);

    }
}
