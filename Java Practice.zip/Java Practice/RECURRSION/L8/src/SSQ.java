// All subseq without using arraylist

import java.util.Scanner;

public class SSQ {

    static void SSQ(String s,String currAns){       // String- abc , currAns - " "
        // Base case
        if(s.length()==0){
            System.out.println(currAns);
            return;
        }
        char curr = s.charAt(0);    // a
        String remaining = s.substring(1);
        // Curr char is part of string
        SSQ(remaining,currAns+curr);

        // Curr char is not a part of string
        SSQ(remaining,currAns);

    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        SSQ(s,"");
    }
}
