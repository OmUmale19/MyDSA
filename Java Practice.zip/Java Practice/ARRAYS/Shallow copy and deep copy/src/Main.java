/* Understand shallow copy and deep copy */

import java.util.Scanner;

class copying{
    static void Shallow(int[] arr){
        Scanner sc = new Scanner(System.in);
        int[] arr2 = arr;
        arr2[0] =5;
        arr2[1] =3;
        arr2[2] =1;
        System.out.println("Array after changes");
        for (int i=0;i<arr2.length;i++){
            System.out.println(arr2[i]);
        }
    }







}
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        int x= sc.nextInt();
        int[] array= new int[x];
        System.out.println("Enter the elements in an array:");
        for (int i=0;i<array.length;i++){
            array[i]= sc.nextInt();
        }
        System.out.println("Entered array:");
        for (int i=0;i<array.length;i++){
            System.out.print(array[i]+" ");
            System.out.println();
        }
        copying.Shallow(array);
    }
}