package UnderFlow_OverFlow;

import java.util.Stack;

public class part1 {
    public static void main(String[] args) {
        Stack<Integer> st = new Stack<>();
        st.push(5); // Insert into stack
        st.push(6);
        st.push(1);
        st.push(3);
        st.push(8);
        st.push(7);

        while(st.size()>0){
            st.pop();
        }
        System.out.println(st);
        st.pop(); // Error
        st.peek();  // Error

    }
}
