// Substring is a continuous part of that string

import java.util.Scanner;

public class Substring {

    static void basic(String s){
        Scanner n = new Scanner(System.in);
        System.out.println("Enter i,j");
        int i = n.nextInt();
        int j = n.nextInt();
        System.out.println(s.substring(i,j));  // i is starting index(including)
        // j end excluding
        System.out.println("---------------");
        System.out.println(s.substring(i));    // i is starting index
    }

    static void Allsub(String s){  // Print all substrings

        for (int i=0;i<s.length();i++){
            for (int j=i+1;j<=s.length()+1;j++){
                System.out.println(s.substring(i,j));
            }
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string");
        String s = sc.nextLine();
//        basic(s);
        Allsub(s);

    }
}
