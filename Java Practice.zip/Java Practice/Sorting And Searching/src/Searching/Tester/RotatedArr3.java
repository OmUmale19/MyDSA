package Searching.Tester;
// Given a rotated sorted array with duplicate elements
// [0,0,0,1,1,1,2,0,0,0] target=2 output = 7

import java.util.Scanner;

public class RotatedArr3 {
    static int Search(int[] arr,int target){
        int n = arr.length;
        int s = 0,e=n-1;

        while (s<=e){
            int mid = s+(e-s)/2;
            if (target == arr[mid]){
                return mid;
            }
            else if (arr[s]==arr[mid] && arr[mid]==arr[e]) {
                s++;
                e--;
            }
            else if (arr[mid] <= arr[e]){
                if (target>arr[mid] && target<=arr[e]){
                    s = mid+1;
                }
                else {
                    e = mid-1;
                }
            }
            else {
                if (target>=arr[s] && target<arr[mid]){
                    e = mid-1;
                }
                else {
                    s = mid + 1;
                }
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        int n = sc.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter the elements in array:");
        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
        while (true) {
            System.out.println("Enter the target");
            int target = sc.nextInt();
            System.out.println("Search :" + Search(arr, target));
        }
    }
}
