/*Given an array, return an array with all even numbers at beginning followed by odd numbers,
and the order of the numbers does not matter*/

import java.util.Arrays;
import java.util.Scanner;
class Operation2{        // To perform operations required in this question

    static void swap(int[] arr,int i,int j){
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    static void MainOpe(int[] arr){     //  To separate even and odd numbers
       int n = arr.length;
       int i=0;
       int j= n-1;

       while (i<j){
           if (arr[i]%2==1 && arr[j]%2==0){
               swap(arr,i,j);
           }
           i++;
           j--;
       }
        System.out.println(Arrays.toString(arr));

    }

}

public class Ques2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array");
        int n = sc.nextInt();
        int[] arr = new int[n];

        System.out.println("Enter the data in array");
        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
        Operation2.MainOpe(arr);

    }
}