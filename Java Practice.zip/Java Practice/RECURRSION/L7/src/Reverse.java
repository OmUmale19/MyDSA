import java.util.Scanner;

// Reverse the string
public class Reverse {

    static String Reverse(String s,int idx){
        if(idx == s.length()){
            return "";
        }
        String S_ans = Reverse(s,idx+1);
        char curr = s.charAt(idx);
        return S_ans + curr;
    }

    public static String Reverse(String s){   // Without index   TC- O(n2)
        if (s.length()== 0){
            return "";
        }
        String S_ans = Reverse(s.substring(1));
        char curr = s.charAt(0);
        return S_ans + curr;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        System.out.println(Reverse(s));
        System.out.println(Reverse(s,0));
    }
}
