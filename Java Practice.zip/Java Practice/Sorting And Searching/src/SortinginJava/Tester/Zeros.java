package SortinginJava.Tester;

import java.util.Arrays;
import java.util.Scanner;

public class Zeros {

    static void zeroatend(int[] arr){
        int zero=0;
        for (int i=0;i<arr.length;i++){
            if (arr[i]==0){
                zero++;
            }
        }
        int k=0;
        for (int i=0;i<arr.length;i++){
            if (arr[i]!=0){
                arr[k++] = arr[i];
            }
        }
        for (int i=arr.length-1-zero;i<arr.length-1;i++){
            arr[k++] = 0;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        int n = sc.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter the elements in array:");
        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
        zeroatend(arr);
        System.out.println(Arrays.toString(arr));
    }
}
