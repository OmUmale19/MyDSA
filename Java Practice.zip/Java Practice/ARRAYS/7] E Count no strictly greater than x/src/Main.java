/* Count the number of elements strictly greater than the target x */

import java.util.Scanner;

class countGreater{     //Class created only to try OOP
    static int count(int[] arr,int target){
        int count = 0;
        for (int i=0;i<arr.length;i++){
            if(arr[i]>target){
                count++;
            }
        }
        return count;
    }

}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        int x= sc.nextInt();
        int[] arr= new int[x];

        System.out.println("Enter the elements of array:");
        for (int i=0;i< arr.length;i++){
            arr[i] = sc.nextInt();
        }

        System.out.println("Enter the target element:");
        int target= sc.nextInt();

        System.out.println("The elements in array strictly greater than "+target+" are:"+countGreater.count(arr,target));
    }
}