// return pairs whose sum equals to target

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Ques2 {

    static List<List<Integer>> Pair(int[] arr,int target){
        List<List<Integer>> Arr = new ArrayList<>();
        List<Integer> inner = new ArrayList<>();

        for (int i=0;i<arr.length;i++){
            for (int j=i+1;j<arr.length;j++){
                if (arr[i]+arr[j] == target){
                    inner.add(i,j);
                    Arr.add(inner);
                }
            }
        }
        return Arr;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        int n = sc.nextInt();
        int[] arr = new int[n];

        System.out.println("Enter the elements of array:");
        for (int i = 0; i < arr.length; i++) {
            arr[i] = sc.nextInt();
        }

        System.out.println("Enter the target:");
        int key = sc.nextInt();   // Key == target

        List<List<Integer>> Ans =Ques2.Pair(arr,key);

        System.out.println("The pairs whose sum equals to target are: "+ Ans);


    }
}
