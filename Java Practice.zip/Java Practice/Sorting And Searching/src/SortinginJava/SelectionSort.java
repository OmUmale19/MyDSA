package SortinginJava;

import java.util.Arrays;
import java.util.Scanner;

public class SelectionSort {

    static void select(int[] arr){
        int n = arr.length;
        int comp=0;
        int swap =0;

        for (int i=0;i<n-1;i++){
            int minIDX = i;

            for (int j=i+1;j<n;j++){
                if (arr[minIDX]>arr[j]){
                    minIDX = j;
                    comp++;
                }
            }
            int temp =arr[minIDX];
            arr[minIDX] = arr[i];
            arr[i] = temp;
            swap++;
        }
        System.out.println("No of comp = "+comp);
        System.out.println("No of swaps = "+swap);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        int[] arr = new int[n];
        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
        select(arr);
        System.out.println(Arrays.toString(arr));
    }

}