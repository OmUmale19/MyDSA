package Practice_Questions;
// Find the next greater element
// ex - arr = [1,5,3,2,1,6,3,4]
//      ans = [5,6,6,6,6,-1,4,-1]

import java.util.Arrays;
import java.util.Scanner;
import java.util.Stack;

public class Quest3 {
    static int[] nextGreater(int[] arr){
        int n =arr.length;
        int[] res = new int[n];
        Stack<Integer> st = new Stack<>();
        st.push(arr[n-1]);
        res[n-1] = -1;

        // Starting from the last sec index
        for (int i=n-2;i>=0;i--){
            while (st.size()>0 && st.peek()<arr[i]){
                st.pop();
            }
            if (st.size()==0) res[i] =-1;
            else res[i] = st.peek();
            st.push(arr[i]);
        }
        return res;
    }

    // Next greater 2
    static int[] nextGreater2(int[] arr){
        int n = arr.length;
        int[] res = new int[n];
        Stack<Integer> st = new Stack<>();
        Arrays.fill(res,-1);
        st.push(0);
        for(int i=1;i<n;i++){
            while (st.size()>0 && arr[st.peek()]<arr[i]){
                res[st.peek()] = arr[i];
                st.pop();
            }
            st.push(i);
        }
        return res;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
//        System.out.println(Arrays.toString(nextGreater(arr)));
        System.out.println(Arrays.toString(nextGreater2(arr)));
    }
}
