import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (1 != 0) {
            System.out.println("Enter No:");
            int n = sc.nextInt();
            int temp = n;
            int ans = temp;

            while (n > 1) {
                ans *= (n - 1);
                n--;
            }
            System.out.println(ans);
        }
    }
}