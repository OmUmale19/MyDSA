import java.util.Arrays;
import java.util.Scanner;


class Operation3{

    static int prefixSum(int[] arr,int end){  // The end point upto which we need prefixsum
        int prefSum = 0;
        for (int i=0;i<=end;i++){
            prefSum += arr[i];
        }
        return prefSum;
    }

    static int suffixSum(int[] arr,int start){  // The start point from which suffix sum is started till end
        int suffixSum = 0;
        for (int i=start;i<arr.length;i++){
            suffixSum += arr[i];
        }
        return suffixSum;
    }

    static int[] suffSumArray(int[] arr){
        int n = arr.length;
        for (int i=(n-1)-1;i>=0;i--){
            arr[i] += arr[i+1];
        }
        return arr;
    }

    static boolean CheckSubArray(int[] arr){
//        for (int i=0;i<arr.length;i++){
//            if (prefixSum(arr,i)==suffixSum(arr,i+1)){
//                return true;
//            }
//        }

        // Find out how????????????
        for (int i=0;i<arr.length;i++){
            int PS = prefixSum(arr,i);
            int SS = prefixSum(arr,arr.length-1)- prefixSum(arr,i);    //prefixSum(arr,arr.length-1) is the total sum of all elements
            if (PS==SS){
                return true;
            }
        }
        return false;
    }

}
public class Ques3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array");
        int n = sc.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter the elements of array");
        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }


//        System.out.println("Status of subArray is: "+Operation3.CheckSubArray(arr));

        System.out.println(Arrays.toString(Operation3.suffSumArray(arr)));

    }
}
