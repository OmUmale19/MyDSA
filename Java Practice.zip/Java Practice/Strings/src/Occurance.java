// Write occurance of string
//ex- aaabbbbccdde
// ans - a3b4c2d2e
import java.util.*;
public class Occurance {

    static String occurance(String s){
        String ans ="";
        char curr = s.charAt(0);
        int count = 1;
        for (int i=1;i<s.length();i++){
            if (s.charAt(i)==curr){
                count++;
            }
            else {
                ans += curr;
                ans +=count;
                count=1;
                curr = s.charAt(i);
            }
        }
        ans+=curr;
        ans+=count;
        return ans;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string");
        String s = sc.nextLine();
        System.out.println(occurance(s));
    }
}
