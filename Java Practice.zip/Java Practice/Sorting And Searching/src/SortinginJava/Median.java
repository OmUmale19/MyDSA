package SortinginJava;

import java.util.Scanner;
public class Median {
    public static int findMedian(int[] arr) {
        int n = arr.length;
        int mid = n / 2;
        if (n % 2 != 0) {  // If the array has an odd number of elements, return the middle element directly
            return quickSelect(arr, 0, n - 1, mid);
        } else {  // If the array has an even number of elements, find the average of the two middle elements
            int leftMiddle = quickSelect(arr, 0, n - 1, mid - 1);
            int rightMiddle = quickSelect(arr, 0, n - 1, mid);
            return (leftMiddle + rightMiddle) / 2;
        }
    }
    public static int quickSelect(int[] arr, int start, int end, int k) {
        if (start == end) {
            return arr[start];
        }int pivotIndex = partition(arr, start, end);
        if (pivotIndex == k) {
            return arr[pivotIndex];
        } else if (pivotIndex > k) {
            return quickSelect(arr, start, pivotIndex - 1, k);
        } else {
            return quickSelect(arr, pivotIndex + 1, end, k);
        }
    }public static int partition(int[] arr, int start, int end) {
        int pivot = arr[end];
        int partitionIndex = start;
        for (int i = start; i < end; i++) {
            if (arr[i] < pivot) {
                int temp = arr[i];
                arr[i] = arr[partitionIndex];
                arr[partitionIndex] = temp;
                partitionIndex++;
            }
        }
        int temp = arr[partitionIndex];
        arr[partitionIndex] = arr[end];
        arr[end] = temp;
        return partitionIndex;
    }  public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number of elements in the array:");
        int n = scanner.nextInt();
        int[] arr = new int[n];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }
        int median = findMedian(arr);
        System.out.println("The median of the array is: " + median);
    }
}
