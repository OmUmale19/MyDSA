import java.util.Scanner;

public class HII {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String a = s.toLowerCase();

        StringBuilder ans = new StringBuilder();
        for (int i=0;i< a.length();i++) {
            if (a.charAt(i) !=' ' ||a.charAt(i) !=',' || a.charAt(i) !=':') {
                ans.append(a.charAt(i));
            }
        }
        System.out.println(ans);
    }
}
