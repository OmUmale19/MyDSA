// Due to immutability of the string
// We came up with the solution using string builder class

import java.util.*;

public class Stringbuilder {

    public static void main(String[] args) {
        StringBuilder s = new StringBuilder("Hello");
        StringBuilder s1 = new StringBuilder(5);  // shows capasity of string

        // Append operation - to add string at end
        s.append('R');   // can add char,int,float,double
        s.append(10);
        System.out.println(s);
        System.out.println("--------------------");

        // setCharAt() - to set/edit char at idx
        s.setCharAt(2,'G');
        s.setCharAt(3,'1');
        System.out.println(s);
        System.out.println("---------------------");

        // insert at idx - to insert new element
        s.insert(2,"PEOPLE");
        s.insert(0,10);
        System.out.println(s);
        System.out.println("---------------------");

        // deleteCharAt - to delete char at
        s.deleteCharAt(2);
        s.deleteCharAt(0);
        System.out.println(s);
        System.out.println("---------------------");

        // delete(i,j) - include i exclude j
        System.out.println( s.delete(2,9));
        System.out.println("---------------------");

        // Reverse the string
        System.out.println(s.reverse());


    }
}
