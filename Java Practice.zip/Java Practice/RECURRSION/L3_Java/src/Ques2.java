/* Given a number. Find sum of natural numbers till 'n' with alternate sign
*  if n=5   ans= 1-2+3-4+5 = 3 */
import java.util.Scanner;
public class Ques2 {
    static int sum(int n){  // Using logic
        if(n%2 ==0){
            return -n/2;
        }
        else {
            return n-(n/2);
        }
    }
    static void sum2(int n){ // Using Recursion

    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the value of n");
        int n = sc.nextInt();
        System.out.println(sum(n));
    }
}
