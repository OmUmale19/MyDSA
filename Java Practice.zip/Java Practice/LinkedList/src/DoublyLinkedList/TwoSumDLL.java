package DoublyLinkedList;

// Give DLL in non-decreasing find 2 nodes with a target sum

import java.util.Scanner;

public class TwoSumDLL {
    static void twosum1(implementation.DLL dub,int target){    // Dub is list of type DLL in implementation
        implementation.node h = dub.head;   // h is a head pointer
        implementation.node t = dub.tail;   // t is a tail pointer
        while (h.data < t.data){   // list in sorted manner
            if (h.data + t.data == target){
                System.out.println(h.data+" & "+t.data+" = "+target);
                break;
            }
            else if (h.data + t.data > target) {
                t = t.prev;
            }
            else {
                h = h.next;
            }
        }
    }

    public static void main(String[] args) {
        implementation.DLL dub = new implementation.DLL();
        dub.insertAtEnd(1);
        dub.insertAtEnd(2);
        dub.insertAtEnd(3);
        dub.insertAtEnd(4);
        dub.insertAtEnd(5);
        dub.insertAtEnd(5);
        dub.insertAtEnd(3);
        dub.insertAtEnd(2);
        dub.insertAtEnd(1);
        implementation.display(dub.head);
        System.out.println("_________________");
        Scanner sc  = new Scanner(System.in);
        System.out.println("Enter target");
        int target = sc.nextInt();
        twosum1(dub,target);
    }
}
