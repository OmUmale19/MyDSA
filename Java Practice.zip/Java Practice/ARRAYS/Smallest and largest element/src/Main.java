/* Find the smallest and largest element in and array also find i'th smallest and largest*/
import java.util.Scanner;
class comparison{
    static int small(int[] arr){
        


    }

}
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        int x= sc.nextInt();
        int[] array= new int[x];
        System.out.println("Enter the elements in an array:");
        for (int i=0;i<array.length;i++){
            array[i]= sc.nextInt();
        }
        System.out.println("Entered array:");
        for (int i=0;i<array.length;i++){
            System.out.print(array[i]+" ");
            System.out.println();
        }
    }
}