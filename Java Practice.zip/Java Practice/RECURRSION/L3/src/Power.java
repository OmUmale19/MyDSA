// Given two number p and q, return p^q
import java.util.Scanner;
public class Power {

    static int power(int p,int q){
        if(q==0){
            return 1;
        }
        if(q==1){
            return p;
        }
        int prev = power(p,q-1);
        return prev * p ;
    }

    static int pow2(int p,int q){
        if (q==0){
            return 1;
        }
        if (q==1){
            return p;
        }
        int subpart = pow2(p,q/2);
        if (q%2 ==0){
            return subpart*subpart;
        }

        return subpart * subpart * p;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the numbers p and q");
        int p = sc.nextInt();
        int q = sc.nextInt();
//        System.out.println(power(p,q));
        System.out.println(pow2(p,q));
    }
}
