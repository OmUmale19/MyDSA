import java.util.Scanner;

class Array{          // Created a class of Array having two methods 1D array and 2D array
    Scanner sc = new Scanner(System.in);
    void Array1D(int x){          // Creating a method for 1D array and x is size of array
        int arr1D[] = new int[x];
        System.out.println("Enter the elements in an array:");
        for (int i=0;i<arr1D.length;i++){
            arr1D[i]= sc.nextInt();
        }
        System.out.println("Entered array:");
        for (int i=0;i<arr1D.length;i++){
            System.out.println(arr1D[i]);
        }
    }

    void Array2D(int x,int y){
    int[][] arr2D= new int[x][y];
        System.out.println("Enter the elements of 2D array:");
        for (int i=0;i<arr2D.length;i++){
            for (int j=0;j<arr2D[x].length;j++){
                arr2D[i][j] = sc.nextInt();
            }
            System.out.println("Entered 2D array");
            for (i = 0; i<arr2D.length; i++){
                for (int j=0;j<arr2D[x].length;j++){
                    System.out.println(arr2D[i][j]);
                }
            }

        }
    }
}


public class Main {
    public static void main(String[] args) {
        System.out.println("Enter the size of array:");
        Scanner sc= new Scanner(System.in);
        int a = sc.nextInt();
        //Array obj1 =new Array();
        //obj1.Array1D(a);

        Array obj2 =new Array();
        obj2.Array2D(a,a);


    }
}