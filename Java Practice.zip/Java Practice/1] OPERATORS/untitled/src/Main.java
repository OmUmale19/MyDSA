/*To understand all types of operators*/

import java.util.Scanner;

class Operators{
    static class Arithmatic{
        static int add(int x,int y){
            int ans = x+y;    // "+" add operator
            return ans;
        }

        static int subt(int x,int y){
            int ans = x-y;  // "-" subtraction operator
            return ans;
        }

        static int product(int x,int y){
            int ans = x*y;    // "*" multiply ope.
            return ans;
        }

        static int div(int x,int y){
            int ans = x/y;   // "/" divide ope.
            return ans;
        }

        static int mod(int x,int y){
            int ans = x%y;   // "%" modulus ope.
            return ans;
        }
    }

    static class Relational{
        static boolean equal(int x, int y){
            if (x==y){
                return true;
            }
            return false;
        }
        static boolean Notequal(int x, int y){
            if (x!=y){
                return true;
            }
            return false;
        }
        static boolean LessThan(int x, int y){
            if (x<y){
                return true;
            }
            return false;
        }
        static boolean GretThan(int x, int y){
            if (x>y){
                return true;
            }
            return false;
        }
        static boolean LTOET(int x, int y){  //LTOET-- less than or equal to
            if (x<=y){
                return true;
            }
            return false;
        }
        static boolean GTOET(int x, int y){  //GTOET-- Greater than or equal to
            if (x>=y){
                return true;
            }
            return false;
        }
    }

    static class Logical{

    }
}
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // Arithmetic operators
        System.out.println("Enter the val of x and y");
        int x = sc.nextInt();
        int y = sc.nextInt();
        System.out.println("__________________________");
//        System.out.println(Operators.Arithmatic.add(x,y));
//        System.out.println(Operators.Arithmatic.subt(x,y));
//        System.out.println(Operators.Arithmatic.product(x,y));
//        System.out.println(Operators.Arithmatic.div(x,y));
//        System.out.println(Operators.Arithmatic.mod(x,y));
        System.out.println("__________________________");

        // Relational Operators
        System.out.println(Operators.Relational.equal(x,y));
        System.out.println(Operators.Relational.Notequal(x,y));
        System.out.println(Operators.Relational.LessThan(x,y));
        System.out.println(Operators.Relational.GretThan(x,y));
        System.out.println(Operators.Relational.LTOET(x,y));
        System.out.println(Operators.Relational.GTOET(x,y));
        System.out.println("__________________________");






    }
}