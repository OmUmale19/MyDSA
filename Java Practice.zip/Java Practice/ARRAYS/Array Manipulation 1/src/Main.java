/* Find the unique element in an array where all elements are repeated twice with one unique element*/
/* Only for +ve no.*/

/*steps
* Take two pointers i and j and travel the array
* check if arr[i] and arr[j] is equal the make both as -1
* travers the array and see which element is not equals to -1
* */

import java.util.Scanner;

class unique{
    static void UniqueEle(int[] arr){
        for (int i=0;i<arr.length;i++){
            for (int j=i+1;j<arr.length;j++){
                if (arr[i]==arr[j]){
                    arr[i] =-1;
                    arr[j] =-1;
                }
            }
        }

        for (int i=0;i<arr.length;i++){
            if (arr[i]!=-1){
                System.out.println("The unique elem found at index:"+i+" which is:"+arr[i]);
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array");
        int n = sc.nextInt(); // n is size
        int[] arr = new int[n];

        for (int i=0;i<arr.length;i++){
            arr[i] = sc.nextInt();
        }
        unique.UniqueEle(arr);

    }
}