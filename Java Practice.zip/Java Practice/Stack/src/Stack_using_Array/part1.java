package Stack_using_Array;


public class part1 {

    public static class Stack{
        private int[] arr = new int[6]; //Array Implementation
        private int idx = 0;  // Iterator

        void push(int x){   // Push function
            if(isFull()){
                System.out.println("Cannot Push element. Stack is Full!!");
                return;
            }
            arr[idx++] = x;
        }

        int peek(){   // Top element
            if(idx==0){
                System.out.println("Stack is Empty !");
                return -1;
            }
            return arr[idx-1];
        }

        int pop(){   // Delete element
            if(idx==0){
                System.out.println("Stack is Empty !");
                return -1;
            }
            int top = arr[idx-1];
            arr[idx-1] = 0;
            idx--;
            return top;
        }

        void display(){
            for(int i=0;i<idx;i++){
                System.out.print(arr[i]+" ");
            }
            System.out.println();
        }

        int size(){
            return idx;
        }

        boolean isEmpty(){
            if(idx==0){
                return true;
            }
            return false;
        }

        boolean isFull(){
            if(idx == arr.length) return true;
            else return false;
        }

    }

    public static void main(String[] args) {
        Stack st = new Stack();
        System.out.println("Is stack empty: "+st.isEmpty());
        System.out.println("---------------------");
        st.push(3);
        st.display();
        st.push(4);
        st.display();
        st.push(5);
        st.display();
        st.push(6);
        st.display();
        st.push(7);
        st.display();
        st.push(8);
        st.display();

        System.out.println("_______________");
        System.out.println(st.peek());

        System.out.println("----------------");
        System.out.println("Popped element :"+st.pop());
        st.display();
        System.out.println("The size is :"+st.size());   // Size

        System.out.println("----------------");
        System.out.println("Popped element :"+st.pop());
        st.display();
        System.out.println("The size is :"+st.size());   // Size

        System.out.println("----------------");
        System.out.println("Is stack empty: "+st.isEmpty());

        System.out.println("-----------------");
        st.push(8);
        st.push(9);
        System.out.println("Is stack full :"+st.isFull());
        st.push(10);

    }
}
