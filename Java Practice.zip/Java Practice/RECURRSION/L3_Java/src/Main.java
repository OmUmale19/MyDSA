// Given a num and k . print k multiples of num
import java.util.Scanner;
public class Main {
    static void printMult(int num,int k){
        if(k==1){
            System.out.println(num);
            return;
        }
        printMult(num,k-1);
        System.out.println(num*k);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the value of num and k");
        int num = sc.nextInt();
        int k  = sc.nextInt();
        printMult(num,k);
    }
}