package DoublyLinkedList;
// Implementation of a doubly linked list

public class implementation {

    public static class node{
        int data;
        node next;
        node prev;
        public node(int data){
            this.data = data;
        }
    }
    public static void display(node head){   //display from head
        node temp = head;
        while (temp!= null){
            System.out.print(temp.data+" ");
            temp = temp.next;
        }
        System.out.println();
    }
    public static class DLL{      // Doubly linked list
        node head;
        node tail;
        int size;

        void insertAtEnd(int data){   //  Insert at end
            node temp = new node(data);
            if (head == null){
                head = temp;
                tail = temp;
            }
            else {
                tail.next = temp;
                temp.prev = tail;
                tail = temp;
            }
            size++;
        }

        // Insert at index
        void insertAtIdx(int data, int idx){
            node temp = head;
            if (idx == size) {
                insertAtEnd(data);
                return;
            }
            node t = new node(data);
            if (head==null){
                head = tail = t;
            }
            if (idx==0){
                t.next = head;
                head.prev = t;
                head = t;
                return;
            }
            for (int i=0;i<idx-1;i++){
                temp = temp.next;
            }

            t.next = temp.next;
            t.prev = temp.next.prev;
            temp.next.prev = t;
            temp.next = t;
            System.out.println("______________________________");
            System.out.println("temp.data - "+temp.data);
            System.out.println("temp.prev.data - "+temp.prev.data);
            System.out.println("temp.next.data - "+temp.next.data);
            System.out.println("temp.next.next.data - "+temp.next.next.data);
            System.out.println("______________________________");
            size++;
        }

        // Delete at index
        void deleteAtIdx(int idx){
            node temp = head;

            if (idx ==0){   // delete head
                head = head.next;
                head.prev = null;
                size--;
                return;
            }

            for (int i=0;i<idx-1;i++){
                temp = temp.next;
            }
            if (idx==size-1){   // delete tail node
                temp.next.prev = null;
                temp.next = null;
                tail = temp;
                size--;
                return;
            }
            temp.next = temp.next.next;
            temp.next.prev = temp;
            size--;
        }

    }
    public static void main(String[] args) {
        DLL d = new DLL();
        d.insertAtEnd(8);
        d.insertAtEnd(9);
        d.insertAtEnd(7);
        display(d.head);
        d.insertAtEnd(18);
        display(d.head);
        System.out.println(d.head.data);
        System.out.println(d.tail.data);

        System.out.println("-----------------------------");
        d.insertAtIdx(45,2);
        display(d.head);
        System.out.println("-----------------------------");
        d.insertAtIdx(12,0);
        display(d.head);

    }
}
