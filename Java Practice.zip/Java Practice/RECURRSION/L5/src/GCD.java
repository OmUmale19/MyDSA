// Given two numbers x and y return Greatest Common Divisor of x and y
// ex- 16 - 1,2,4,8,16
// ex- 12 - 1,2,3,4,6,12
// Ans - GCD(16,12) = 4

import java.util.Scanner;

public class GCD {
    static int gcd(int x,int y){   // Brute force
        int ans =1;
        int min = Math.min(x, y);
        for (int i=min;i>0;i--){
            if(x%i==0 && y%i==0){
                return i;
            }
        }
        return ans;
    }

    static int gcdLong(int x,int y){   // Long division method
        int ans =1;
        while ( x%y!=0 ){
            int temp = y;
            y = x%y;
            x = temp;
            ans =y;
        }
        return ans;
    }

    static int GCDlong(int x,int y){    // Using recursion
        if(x%y ==0){
            return y;
        }
        return GCDlong(y,x%y);
    }

    static int LCM(int x,int y){
        int lcm = (x*y)/ GCDlong(x, y);
        return lcm;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the values of x and y");
        int x = sc.nextInt();
        int y = sc.nextInt();
        System.out.println(GCDlong(x,y));
        System.out.println(LCM(x,y));
    }
}