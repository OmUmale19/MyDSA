import java.util.ArrayList;
import java.util.List;

public class Main {
    List<Integer> getMintime(int cache_size,int cache_time,int server_time,List<String> urls){
        List<Integer> ans = new ArrayList<>();
        String[] cache = new String[cache_size];
        int i=0;
        boolean flag = false;
        for(String url : urls ){
            flag = false;
            for (int j=0;j<cache.length;j++){
                if(url.equals(cache[j])){
                    break;
                }
            }
        }
        if(flag){
            ans.add(cache_time);
        }
        else {
            ans.add(server_time);
            if (i==cache_size){
                i=0;
            }
            cache[i++] = urls.toString();
        }
        return ans;
    }
    public static void main(String[] args) {

    }
}