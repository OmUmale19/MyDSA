package SortinginJava;

import java.util.Arrays;

public class Swap {
    public static void Swapping(int[] arr,int i,int j){
        // Using temp var
//        int temp = arr[i];
//        arr[i] = arr[j];
//        arr[j] = temp;

        // Using Arith +-
//        arr[i] = arr[i] + arr[j];
//        arr[j] = arr[i] - arr[j];
//        arr[i] = arr[i] - arr[j];

        // Using Mul,Div
//        arr[i] = arr[i] * arr[j];
//        arr[i] = arr[i] / arr[j];
//        arr[j] = arr[i] / arr[j];

        // Using XOR
        arr[i] = arr[i] ^ arr[j];
        arr[j] = arr[i] ^ arr[j];
        arr[i] = arr[i] ^ arr[j];
    }

    public static void main(String[] args) {
        int[] arr = {5,4,3,2,1};
        Swapping(arr,1,3);
        System.out.println(Arrays.toString(arr));
    }
}
