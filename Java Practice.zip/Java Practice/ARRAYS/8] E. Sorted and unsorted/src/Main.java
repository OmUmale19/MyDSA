/*Check whether the given array is a sorted array or unsorted
* If sorted return true else return false*/

import java.util.Scanner;

class sort{       //To check sorted array
    static boolean isSort(int[] arr){
        boolean status = true;

        for (int i=0;i<arr.length;i++){
            int j =i+1;
            if(j<arr.length && arr[i]>arr[j]){
                return false;
            }
        }
        return status;
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        int n= sc.nextInt();
        int[] array= new int[n];

        System.out.println("Enter the elements in an array:");
        for (int i=0;i<array.length;i++){
            array[i]= sc.nextInt();
        }

        System.out.println("Status of array sorting is:"+sort.isSort(array));
    }
}