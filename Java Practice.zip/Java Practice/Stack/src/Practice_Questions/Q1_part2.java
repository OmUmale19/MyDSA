package Practice_Questions;

import java.util.Scanner;
import java.util.Stack;

// Find the minimum number of brackets removed to make string balance
// ex - )()())(
// ans - 3

public class Q1_part2 {
    static int min;
    static int remove(String s){
        Stack<Character> st = new Stack<>();

        for(char ch : s.toCharArray()){
            if(ch=='('){
                st.push(ch);
                min++;
            }
            else {
                if(st.isEmpty()){
                    min++;
                }
                else {
                    st.pop();
                    min--;
                }
            }
        }
        return min;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        System.out.println(remove(s));
    }
}
