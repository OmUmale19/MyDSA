// WAP to return all subsequences in an arraylist

import java.util.ArrayList;
import java.util.Scanner;

public class Subseq{

    public static ArrayList<String> subseq(String s){
        ArrayList<String> ans = new ArrayList<>();
        // base case
        if (s.length()==0){
            ans.add("");
            return ans;
        }

        char curr_char = s.charAt(0);
        //Recursive work
        ArrayList<String> S_ans = subseq(s.substring(1));

        //  Self work
        for (String s1 : S_ans){
            ans.add(s1);
            ans.add(curr_char+s1);
        }

        return ans;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        ArrayList<String> ans = subseq(s);
//        for (int i=0;i<ans.toArray().length;i++){
//            System.out.println(ans.get(i));
//        }
        for (String s1 : ans){
            System.out.println(s1);
        }
    }
}