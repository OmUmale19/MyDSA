import java.util.Arrays;
import java.util.Scanner;

// Print 1 to n
public class Print_1t0n {

    static void rec(int[] arr, int n){
        arr[n-1] = n;
        if(n==1){
            arr[0]=1;
            return;
        }
        rec(arr,n-1);
        int j=(n-1)-1;
        arr[j++] = n-1;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number:");
        int n = sc.nextInt();
        int[] arr = new int[n];
        rec(arr,n);
        System.out.println(Arrays.toString(arr));
    }
}
