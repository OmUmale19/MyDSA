public class Test {
    public static void main(String[] args) {
        String name = "OmUmale";
        System.out.println(name.length());
        System.out.println(name.charAt(0));

    }
}
