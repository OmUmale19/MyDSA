import java.util.Scanner;

public class NewQue {

    static int count(int n){

        if(n>=0 && n<=9){
            return 1;
        }

        int previousDigitCount = count(n/10);
        int lastcount = 1;
        return previousDigitCount + lastcount;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number");
        int n = sc.nextInt();
        System.out.println(count(n));
    }
}
