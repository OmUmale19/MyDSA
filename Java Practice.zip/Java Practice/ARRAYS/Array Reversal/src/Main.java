// Array Reversal
import java.util.Scanner;

class ArrayReversal{
    static void PrintArray(int[] arr){
        for (int i=0;i<arr.length;i++){
            System.out.println(arr[i]);
        }
    }

    static void Reverse1(int[] arr){
        int n = arr.length;
        int[] arr2 = new int[n];  // A new array is created
        int j =0;

//        for (int i=n-1;i>=0;i--){   // Start from back of arr
////            arr2[j] = arr[i];       // Start from front of arr2 and store the value in arr2
////            j++;                   // increase j
//            // Instead
//            arr2[j++] = arr[i];    // Starting with 0 , j will increment its value in each for loop
//        }

        int i=n-1;
        while (i>=0){
            arr2[j++] = arr[i];
            i--;
        }
        PrintArray(arr2);
    }

    static void Swap(int[] arr,int i,int j){
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    static void Reverse2(int[] arr){
        int n=arr.length;
        int i=0;
        int j =n-1;
        for (int k=0;k<n;k++){
            if (i<=j) {
                Swap(arr, i, j);
                i++;
                j--;
            }
        }
        PrintArray(arr);
    }


}


public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter size of array");
        int n = sc.nextInt();
        int[] arr =  new int[n];

        for (int i=0;i<arr.length;i++){
            arr[i]= sc.nextInt();
        }

       ArrayReversal.Reverse1(arr);
        System.out.println("......................");
        ArrayReversal.Reverse2(arr);

    }
}